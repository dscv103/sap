import reserveBook, { Db, Book, Patron } from '../../src/api/reserve';

function fakeDb(initial: Book[]): { db: Db, reads: string[], writes: Array<{bookId: string, patronId: string}> } {
  const store = new Map(initial.map(b => [b.id, { ...b }]));
  const reads: string[] = [];
  const writes: Array<{bookId: string, patronId: string}> = [];
  return {
    db: {
      async getBook(id: string) {
        reads.push(id);
        return store.get(id) ?? null;
      },
      async setHold(bookId: string, patronId: string) {
        writes.push({ bookId, patronId });
        const b = store.get(bookId);
        if (b) {
          b.status = 'on_hold'; // REQ:101 AC:1
          b.holdBy = patronId; // REQ:101 AC:1
        }
      }
    },
    reads, writes
  };
}

describe('[REQ-101] reservation core', () => {
  test('AC-1_reserve_success_sets_on_hold', async () => {
    const { db, writes } = fakeDb([{ id: 'b1', status: 'available' }]);
    const patron: Patron = { id: 'p1', authenticated: true };
    const res = await reserveBook({ bookId: 'b1', patronId: 'p1' }, db, patron);
    expect(res).toEqual({ ok: true, status: 'On Hold' }); // REQ:101 AC:1
    expect(writes).toEqual([{ bookId: 'b1', patronId: 'p1' }]); // REQ:101 AC:1
  });

  test('AC-2_reserve_unavailable_shows_error', async () => {
    const { db } = fakeDb([{ id: 'b2', status: 'on_hold', holdBy: 'p2' }]);
    const patron: Patron = { id: 'p1', authenticated: true };
    const res = await reserveBook({ bookId: 'b2', patronId: 'p1' }, db, patron);
    expect(res).toEqual({ ok: false, error: 'Not available for reservation' }); // REQ:101 AC:2
  });

  test('not_authenticated_is_blocked', async () => {
    const { db } = fakeDb([{ id: 'b3', status: 'available' }]);
    const patron: Patron = { id: 'p1', authenticated: false };
    const res = await reserveBook({ bookId: 'b3', patronId: 'p1' }, db, patron);
    expect(res).toEqual({ ok: false, error: 'Not authenticated' });
  });

  test('not_found_book', async () => {
    const { db } = fakeDb([]);
    const patron: Patron = { id: 'p1', authenticated: true };
    const res = await reserveBook({ bookId: 'missing', patronId: 'p1' }, db, patron);
    expect(res).toEqual({ ok: false, error: 'Not found' });
  });
});
