Task: Evaluate outcomes and record ADR
Phase: Evaluate
Context: test results, metrics, screenshots
Constraints: Be precise about evidence
Deliverables: diffs, tests, docs, ADR (if needed)
Checks: make contracts:test
Trace: ADR-###

- Recommend ship/iterate/revert with follow-ups.
