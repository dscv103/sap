# GitHub Issue Templates

This repository includes a set of **organized issue templates** under `.github/ISSUE_TEMPLATE/`.
They provide structured, unambiguous formats for creating issues, aligned with a **spec-driven workflow**.

## Templates Overview

### 🚀 Feature Request (`feature_request.yml`)
Use this for new features or capabilities.
- Includes links to `requirements.md`, `design.md`, `tasks.md`.
- Encourages acceptance criteria in **EARS format**.
- Tracks dependencies, rollout, and validation.

### 🛠️ Chore / Maintenance (`chore_request.yml`)
For refactors, infrastructure, CI/CD, and documentation work.
- Defines scope (in/out).
- Requires acceptance criteria focused on **non-functional deliverables**.

### 🐞 Bug Report (`bug_report.yml`)
For defects or regressions.
- Captures repro steps, expected vs. actual, environment, logs.
- Severity dropdown (S1–S4).
- Acceptance criteria ensures **tests and CI green**.

### 📉 Technical Debt (`tech_debt.yml`)
For documenting and scheduling remediation of known debt.
- Captures location, impact, and remediation plan.
- Requires priority + effort sizing (XS–XL).
- Links back to decision records if applicable.

### 📊 Epic / Initiative (`epic.yml`)
For large cross-cutting goals composed of multiple child issues.
- Tracks milestones, outcomes, and traceability to linked issues.
- Provides **planning structure** for broader initiatives.

### ⚙️ Config (`config.yml`)
- Disables blank issues.
- Directs Q&A to Discussions.

## Usage Guidelines

1. **One Issue per Task**
   Each task in `tasks.md` should map to a single issue. Avoid bundling.

2. **Traceability Required**
   Every issue must link back to `requirements.md`, `design.md`, and/or `tasks.md`.
   This ensures clarity for both humans and AI agents (like gpt-5-mini).

3. **Acceptance Criteria Must Be Testable**
   Issues should include objective, verifiable criteria (unit tests, logs, or CI checks).

4. **Validation & Handoff**
   Issues are not complete until validation steps are logged and PRs include:
   - Streamlined Action Log
   - Compressed Decision Records
   - Links to requirements/design/tasks

## Example Workflow

- Add a new feature → Use **Feature Request** template.
- Fix a bug → Use **Bug Report**.
- Refactor a workflow → Use **Chore**.
- Document cleanup debt → Use **Technical Debt**.
- Plan a release milestone → Use **Epic**.

---

✅ By using these templates, your repo will maintain **clarity, consistency, and traceability** across all issues.
