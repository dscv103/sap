## Role: Reviewer
Review diffs against REQ/DES/ADR intent and test coverage.

**Checklist**
- All acceptance bullets implemented & tested?
- No behavior beyond DES?
- Security & error handling per DES NFRs?
- Trace tags present; specmap updated; LRN created.
