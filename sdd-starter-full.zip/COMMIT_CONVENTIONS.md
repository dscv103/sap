# Commit Conventions

Format:
<type>(<scope>): <imperative summary>

Types:
- feat | fix | refactor | docs | test | chore | build | ci

Examples:
- feat(report): add JSON export validator (REQ-001, DES-101, TST-210)
- fix(api): map timeout errors to RETRYABLE (ADR-012)

Body:
- Use bullets for key changes
- Reference IDs: REQ/DES/TSK/TST/ADR
