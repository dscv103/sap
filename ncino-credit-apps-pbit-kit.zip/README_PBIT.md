# nCino Credit Card Application – Power BI Template Kit

This kit lets you produce a **.PBIT** with model, measures, and visuals pre‑wired.

## What’s included
- `model/create_model.tmsl.json` – Tabular Model script (tables, M partitions for CSVs, relationships, measures, Date table).
- `data/*.csv` – sample data used by the model (you can point to your own sources later).
- `report/deneb/*.json` – optional Deneb (Vega‑Lite) specs for the key visuals (bar, funnel) if you prefer a custom visual.
  
> Default data folder used in the M queries is `C:\ncino-sample\`. Either copy the three CSVs there OR change the `Path` line in each query.

## Steps (build once, then Save As .PBIT)
1) **Prepare sample files**  
   Copy `/data` files to `C:\ncino-sample\` on your machine.

2) **Open a blank Power BI Desktop file**

3) **Push the model**
   - Open **Tabular Editor** (External Tools) from Power BI Desktop.
   - `File → Open...` connects to the current model automatically.
   - `Model → Import TMSL / From File...` and select `model/create_model.tmsl.json`.
   - Click **OK**, then **Save** in Tabular Editor (this writes the model back to Power BI).

4) **Refresh data**
   - Back in Power BI Desktop, click **Refresh** to load the CSVs.
   - (Optional) In **Transform data → Advanced Editor**, update the `Path` variable in each query to your real folder or to your nCino/Salesforce source.

5) **Add visuals (pre‑wired options)**
   - *Native visuals:*  
     - Clustered column chart: Axis = `stages[StageName]`; Values = `KPI[Avg Stage Days]`; Sort by `stages[StageOrder]` ascending.
     - Funnel chart: Category = `stages[StageName]`; Values = `KPI[Reached Stage Apps]`; Sort by `StageOrder`.
     - Line chart: X = `Date[Month]`; Y = a measure like `KPI[Total Apps]` filtered to Approved.
     - Card KPIs: `KPI[Active WIP]`, `KPI[Cycle Time Days]`, `KPI[SLA Breach Rate]`, `KPI[Total Apps]`.
   - *Deneb custom visuals (optional)*:
     - Install **Deneb** from AppSource → Add a visual.
     - Paste the JSON from `report/deneb/avg_stage_days.json` and `funnel_reached_apps.json` into Deneb; bind fields where prompted.

6) **Save as Template**
   - `File → Export → Power BI template (.pbit)` and choose which parameters to expose (e.g., a Folder Path parameter once you add one).

## Moving to nCino/Salesforce
Replace the CSV M expressions with:
- Salesforce/nCino object queries or report exports (via **Salesforce Objects** connector or **OData**/**REST**).
- Preserve table/column names so the measures and visuals continue to work.

## Measures included
- Stage Days, Avg Stage Days, Reached Stage Apps, Total Apps, Active WIP, Cycle Time Days, SLA Breaches, SLA Breach Rate, Drop‑off %

## Relationships
- stage_history[ApplicationID] → applications[ApplicationID] (1→* from applications)
- stage_history[StageKey] → stages[StageKey] (1→* from stages)

---
Tip: Add a **FolderPath** parameter (Transform Data → Manage Parameters) and replace the `Path = "C:\\ncino-sample\\"` line in each query with `Path = FolderPath` for easy portability.
