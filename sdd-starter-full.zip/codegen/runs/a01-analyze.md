Task: Draft REQ-### in EARS with concrete examples
Phase: Analyze
Context: spec/requirements (new file), existing README, domain notes
Constraints: User-observable behavior only, no implementation
Deliverables: diffs, tests, docs, ADR (if needed)
Checks: make contracts:test
Trace: REQ-###

- Capture success criteria and non-goals.
- Propose test list names (TST-###).
