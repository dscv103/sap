---
id: DES-000
relates_to: [REQ-###]
phase: Design
summary: <contract and interface design>
interfaces:
  input: <schema ref or IDL>
  output: <schema ref or IDL>
invariants:
  - <domain invariant>
error_taxonomy:
  - code: <ERR_CODE>
    when: <condition>
    message: <stable, user-safe message>
compatibility:
  change_type: <additive|breaking>
  notes: <strategy and deprecation timeline>
test_plan_refs: [TST-###]
---

## Notes
- Prefer additive compatibility; version breaking changes.
