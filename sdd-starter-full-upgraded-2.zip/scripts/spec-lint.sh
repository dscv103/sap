#!/usr/bin/env bash
# Tiny spec linter for local use (SDD / The New Code)
# Checks:
#  1) Each REQ file contains an "Acceptance Criteria" section
#  2) Each DES file contains a "Minimal Slices Plan" section
# Usage: scripts/spec-lint.sh [--strict]
set -euo pipefail

STRICT=0
if [[ "${1:-}" == "--strict" ]]; then
  STRICT=1
fi

errs=0
warns=0

shopt -s nullglob

echo "==> REQ: Checking 'Acceptance Criteria' in spec/requirements/*.md"
for f in spec/requirements/*.md; do
  if ! grep -qi "Acceptance Criteria" "$f"; then
    echo "ERROR: Missing 'Acceptance Criteria' section in $f"
    ((errs++))
  fi
done

echo "==> DES: Checking 'Minimal Slices Plan' in spec/design/*.md"
for f in spec/design/*.md; do
  if grep -q "^---" "$f"; then
    if ! grep -qi "Minimal Slices Plan" "$f"; then
      if [[ "$STRICT" == "1" ]]; then
        echo "ERROR: No 'Minimal Slices Plan' found in $f"
        ((errs++))
      else
        echo "WARN: No 'Minimal Slices Plan' found in $f"
        ((warns++))
      fi
    fi
  fi
done

echo "==> Summary: errors=$errs, warnings=$warns (strict=$STRICT)"
if [[ "$errs" -gt 0 ]]; then
  exit 1
fi
echo "OK"
