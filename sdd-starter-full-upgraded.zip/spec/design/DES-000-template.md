---
id: DES-000
relates_to: [REQ-###]
phase: Design
owner: <tech lead>
date: <YYYY-MM-DD>
---

# Design Specification (SDD / The New Code)

## Architecture Overview
- Components and interactions (frontend, backend, data, external services)
- Simple sequence of the primary flow

## Contracts (First)
- API/IDL/Schema definitions (versioned, additive by default)
- References:
  - JSON Schema: spec/design/schemas/<name>.v1.json
  - OpenAPI/GraphQL (optional)

## Data Model
- Entities/fields, constraints, indexing notes

## Invariants & Policies
- Business invariants, pre/postconditions
- Idempotency, deduplication, ordering, retries

## Error Taxonomy
- code: <ERR_CODE> — condition — user-safe message — action (retry|fail|log|alert)

## Minimal Slices Plan
1. Slice 1 (happy path) — minimal end-to-end
2. Slice 2 (errors/edge cases)
3. Slice 3 (flags/observability/perf)

## Compatibility Strategy
- Additive change policy, versioning, migration/rollback

## Observability
- Logs/events/metrics; dashboards and alerts

## Security & Privacy
- AuthN/Z, PII handling, secrets, tenancy

## Performance Budgets
- Targets, load assumptions, caching

## Rollout
- Feature flags, canary, kill switch

## Test Strategy
- Contract tests, unit/integration, e2e smoke

## Open Questions
- Items requiring follow-up ADRs
