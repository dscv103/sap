# pypkgdoc – Overleaf-ready LaTeX template for Python package docs

## Quick start on Overleaf
1) Upload this ZIP to Overleaf and unzip it.
2) Menu → Settings:
   - Main document: `main.tex`
   - Compiler: **pdfLaTeX** (default). Works out of the box.
3) Click **Recompile**.

### Optional: use `minted` (Pygments) for code
- Menu → Settings → enable **Shell escape** (Allow running external programs).
- Choose **LuaLaTeX** (recommended) or keep pdfLaTeX.
- In `main.tex`, change the documentclass line to:
  `\documentclass[colorlinks,minted]{pypkgdoc}`

## Notes
- Fonts are Overleaf-safe by default (`newpxtext/newpxmath` + `inconsolata`).
- For nicer system fonts, switch compiler to **LuaLaTeX** or **XeLaTeX** (no other changes needed).
- Code blocks: use `\pycode{path/to/file.py}` to include files; use `\code{inline}` for inline code.
