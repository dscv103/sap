import sys,json,glob
from jsonschema import validate, ValidationError
if len(sys.argv)<3: sys.exit(2)
sch=json.load(open(sys.argv[1]))
files=[]
for g in sys.argv[2:]:
    files+=glob.glob(g)
fails=0
for p in files:
    try:
        validate(json.load(open(p)), sch)
        print("OK", p)
    except ValidationError as e:
        print("DRIFT", p, "-", e.message)
        fails=1
sys.exit(fails)
