# SETUP — Codegen Sandbox Setup Commands

Use these commands in **Codegen → Repo Settings → Setup Commands** to prime the sandbox
so your agent runs can execute contract tests and common tooling quickly. After a successful
setup, take a **Snapshot** to speed up subsequent runs.

## Assumptions
- Ubuntu-based sandbox with bash
- Python ≥ 3.12 available (jsonschema compatible)
- Node.js ≥ 20 available (AJV 8 compatible)
- Your repo includes the SDD scaffold, Makefile/justfile, and polyglot validators

---

## One-time Setup Commands (paste into Codegen)

```bash
# ---------- Python ----------
# Prefer Python 3.12 for widest wheel availability
if command -v pyenv >/dev/null 2>&1; then
  pyenv install -s 3.12.0
  pyenv local 3.12.0
fi

python -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
if [ -f tools/contracts/python/requirements.txt ]; then
  pip install -r tools/contracts/python/requirements.txt
fi

# ---------- Node ----------
# Use Node 20 LTS
if command -v nvm >/dev/null 2>&1; then
  nvm install 20
  nvm use 20
fi

if [ -f tools/contracts/node/package.json ]; then
  pushd tools/contracts/node >/dev/null
  npm ci
  popd >/dev/null
fi

# ---------- Sanity Checks ----------
# Run contract validators to warm caches and verify environment.
if command -v make >/dev/null 2>&1; then
  make contracts:test || true
elif command -v just >/dev/null 2>&1; then
  just contracts-test || true
fi
```

> Tip: After this completes, click **Snapshot** in Codegen so future runs skip installation.

---

## Optional: System packages (if your stack needs them)
```bash
sudo apt-get update -y
sudo apt-get install -y build-essential pkg-config
```

---

## Environment Variables
If your tests require non-secret config, set environment variables in **Repo Settings → Environment**.
For secrets, use Codegen’s **Secrets** feature and reference them via environment variables from your code.

---

## Ports & Web Preview (optional)
If you add a demo server later, expose it on **port 3000** to use Codegen’s Web Preview tab.

---

## CI Parity
Your GitHub Actions file `.github/workflows/contracts-test.yml` runs the same commands as above.
Keep Makefile/justfile targets as the single source of truth to ensure local, CI, and sandbox behavior match.

---

## Troubleshooting
- **Missing Python wheels**: Pin Python to 3.12 as shown above.
- **Node version mismatch**: Ensure Node 20 is active (`node -v` prints `v20.x.y`).
- **Schema/fixture failures**: Run `make contracts:test` locally; fix schema or fixtures; re-run in sandbox.
