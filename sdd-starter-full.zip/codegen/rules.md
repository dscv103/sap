# Codegen Agent Rules (Repo-Local)

These mirror and enforce your repository rules for automated runs:

1) **Small scoped tasks** tied to `TSK-###` with trace refs to `REQ/DES/TST/ADR`.
2) **Stacked branches**: `feat/<slug>-01` → base `main`; `-02` → base `-01`, etc.
3) **Tests as spec**: write/extend failing tests first; keep unit fast and deterministic.
4) **Contracts**: update schemas with compatibility notes and add contract tests.
5) **Diff quality**: minimal, stylistically consistent; no speculative refactors.
6) **Definition of Done** aligns to phase gates; PR template must be satisfied.
