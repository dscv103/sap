#!/usr/bin/env python3
from __future__ import annotations
import re, os, sys, json, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC_DIRS = [ROOT / "src", ROOT / "tests"]
OUT = ROOT / "docs" / "TRACEABILITY.md"
OUT.parent.mkdir(parents=True, exist_ok=True)

TRACE_RE = re.compile(r"REQ:(\d+)\s+AC:(\d+)")
TEST_NAME_RE = re.compile(r"test\(['\"](AC-(\d+)_.*?)['\"]")

def scan_files():
    traces = []  # {file, line, req, ac}
    tests = []   # {file, name, ac}
    for base in SRC_DIRS:
        for p in base.rglob("*.*"):
            if p.suffix not in {".ts", ".js"}:
                continue
            with p.open("r", encoding="utf-8", errors="ignore") as f:
                for i, line in enumerate(f, 1):
                    for m in TRACE_RE.finditer(line):
                        traces.append({"file": str(p.relative_to(ROOT)), "line": i, "req": m.group(1), "ac": m.group(2)})
                    tm = TEST_NAME_RE.search(line)
                    if tm:
                        tests.append({"file": str(p.relative_to(ROOT)), "name": tm.group(1), "ac": tm.group(2)})
    return traces, tests

def render(traces, tests):
    by_req = {}
    for t in traces:
        by_req.setdefault(t["req"], {"code": [], "tests": []})["code"].append(t)
    for t in tests:
        by_req.setdefault("?", {"code": [], "tests": []})["tests"].append(t)

    lines = ["# Traceability Matrix", "", "| REQ | AC | Code (file:line) | Tests |", "|---|---|---|---|"]
    # Build AC coverage by matching test names AC-<n> with trace AC
    for req, bucket in sorted(by_req.items(), key=lambda x: x[0]):
        # Aggregate ACs from code traces
        acs = sorted({t["ac"] for t in bucket["code"]})
        if not acs:
            continue
        for ac in acs:
            code_locs = [f"{t['file']}:{t['line']}" for t in bucket["code"] if t["ac"] == ac]
            test_names = [t["name"] for t in tests if t["ac"] == ac]
            lines.append(f"| REQ-{req} | {ac} | {', '.join(code_locs)} | {', '.join(test_names) or '—'} |")
    return "\n".join(lines) + "\n"

def main():
    traces, tests = scan_files()
    OUT.write_text(render(traces, tests), encoding="utf-8")
    print(f"Wrote {OUT}")

if __name__ == "__main__":
    main()
