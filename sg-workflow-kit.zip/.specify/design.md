# NixOS Configuration — Design (docs‑only, contracts)

**Spec reference:** `./.specify/spec.md` v1.5  
**Scope:** Define contracts and boundaries to implement the Spec using **flake‑parts** and feature modules.  
**Note:** This kit includes *no code files*. Use these contracts during implementation.

---

## 0) Architecture & Assembly

- **Feature modules**: Kernel, Filesystem, Desktop, GPU, CPU/Perf, Network, Audio, Locale/Time, Binary‑Cache, Dev, Shell, Terminal, Security, Observability, Backup, User(HM).  
- **Composition**: flake‑parts aggregates modules; one host (`blazar`) imports them.  
- **Traceability**: Each module lists the **REQ IDs** it satisfies and the **Exposed options** it must set at implementation time.

---

## 1) Contracts

Each table uses the same schema: **Depends → Inputs → Exposes → Satisfies → Failure Modes**.

### 1.1 Kernel
| Field | Value |
|---|---|
| Depends | nixpkgs pin |
| Inputs | `package` (default: latest stable at pin) |
| Exposes | `boot.kernelPackages` |
| Satisfies | REQ‑KERNEL‑001..003, REQ‑GLOBAL‑001..002 |
| Failure Modes | ABI breaks GPU; mitigated via ADR + temporary LTS pin + rollback |

### 1.2 Filesystem/Boot
| Field | Value |
|---|---|
| Depends | Kernel |
| Inputs | LUKS device path, mapper name, `bcachefs` opts |
| Exposes | `boot.initrd.luks.devices`, `fileSystems."/"`, systemd‑boot |
| Satisfies | REQ‑FS‑001..004 |
| Failure Modes | Wrong device mapping; system unbootable → recovery + doc |

### 1.3 Desktop (Wayland GNOME)
| Field | Value |
|---|---|
| Depends | GPU |
| Inputs | `enableXWayland` (default true) |
| Exposes | GDM Wayland, GNOME desktop |
| Satisfies | REQ‑DESK‑001..002 |
| Failure Modes | Fallback to Xorg → **reject unless ADR** |

### 1.4 GPU (NVIDIA)
| Field | Value |
|---|---|
| Depends | Kernel |
| Inputs | `enable` (default true), `vulkan` (true), `open` (false) |
| Exposes | `hardware.nvidia.*`, `videoDrivers`, Vulkan tools |
| Satisfies | REQ‑GPU‑001..003 |
| Failure Modes | Driver/kernel mismatch; Vulkan ICD missing |

### 1.5 Network (Ethernet‑only)
| Field | Value |
|---|---|
| Depends | none |
| Inputs | backend (`NetworkManager` or `networkd`), hostname, SSH toggle |
| Exposes | Firewall default‑deny; radios disabled; Ethernet configured |
| Satisfies | REQ‑NET‑001..003 |
| Failure Modes | Radios accidentally enabled → CI policy test blocks |

### 1.6 Audio
| Field | Value |
|---|---|
| Depends | Desktop |
| Inputs | `lowLatency` (bool) |
| Exposes | PipeWire + WirePlumber; PulseAudio disabled |
| Satisfies | REQ‑AUDIO‑001 |
| Failure Modes | Conflicting audio services |

### 1.7 Locale/Time
| Field | Value |
|---|---|
| Depends | none |
| Inputs | locale (`en_US.UTF‑8`), timezone (`America/Chicago`) |
| Exposes | `i18n.defaultLocale`, `time.timeZone` |
| Satisfies | REQ‑LOCALE‑001..002 |

### 1.8 Binary‑Cache
| Field | Value |
|---|---|
| Depends | none |
| Inputs | substituters list; trusted keys list |
| Exposes | `nix.settings.substitute=true`, `substituters`, `trusted-public-keys` |
| Satisfies | REQ‑BINCACHE‑001..004 |
| Failure Modes | Keys mismatch; cache outage (falls back to build, SLO‑6 hit) |

### 1.9 Dev UX
| Field | Value |
|---|---|
| Depends | HM, Shell |
| Inputs | VS Code flavor; Python flavor; direnv enable |
| Exposes | Editor presence; dev shells; direnv integration |
| Satisfies | REQ‑DEV‑001..002 |
| Failure Modes | `settings.json` overwritten → policy test |

### 1.10 Shell/Terminal
| Field | Value |
|---|---|
| Depends | HM |
| Inputs | extra CLI packages; Ghostty package |
| Exposes | Default shell Zsh + Starship; Ghostty default terminal |
| Satisfies | REQ‑SHELL‑001, REQ‑TERM‑001 |

### 1.11 Security/Observability/Backup
| Field | Value |
|---|---|
| Depends | none |
| Inputs | sops on/off; journald persistence; backup tool |
| Exposes | sops (if enabled); journald rotation; backup scaffolding |
| Satisfies | REQ‑SEC‑001, REQ‑OBS‑001, REQ‑BKP‑001 |

---

## 2) Cross‑Cutting Policies

- **Binary‑cache first** (REQ‑BINCACHE‑001..004).  
- **Wired‑only networking** (REQ‑NET‑001..003).  
- **VS Code `settings.json` user‑mutable** (REQ‑DEV‑001).  
- **Traceability**: Changes must update REQs ↔ Design ↔ Tasks ↔ Tests; otherwise CI fails during implementation.

---

## 3) Testing Strategy (concept)

- **Spec‑lint**: Section presence, REQ ID format.  
- **AC probes**: kernel, session, GPU, audio, network radios, substitution‑rate.  
- **Stoplight** output: Green (complete), Yellow (needs tests), Red (needs code).

---

## 4) Open Questions

- Choose network backend (NM vs networkd).  
- Python workflow: `uv`, `poetry`, or `venv` baseline.  
- Backup strategy for bcachefs.

