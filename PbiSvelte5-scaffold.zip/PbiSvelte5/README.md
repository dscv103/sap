# PbiSvelte5 scaffold

## Install

```bash
npm install
npm run cert
npm run start
```

Open Power BI Desktop or Service in developer mode and load the visual from the local dev server.

## Package

```bash
npm run package
```

The `.pbiviz` package is written to `dist/`.

## Notes

- Replace the placeholder author name and email in `pbiviz.json` before shipping.
- Replace `assets/icon.png` with your real icon.
- This starter is a minimal metric-card visual so the Svelte 5 bridge stays small and easy to extend.
