# AGENTS.md — Repository Rules for Codegen Agents (Polyglot, SDD)

## Prime Directives
- Ship minimal end-to-end core first; one feature at a time.
- Tests are the spec; write failing tests first for new behavior.
- Keep files ≈250 LOC and split by responsibility (domain, adapters, orchestrators).
- Contracts first (JSON Schema/OpenAPI/IDL); prefer additive compatibility.

## Process — The New Code (Analyze → Design → Implement → Evaluate)
- **Analyze**: EARS `REQ-###` with examples + success criteria + non-goals.
- **Design**: `DES-###` + schema + invariants + error taxonomy + compatibility notes.
- **Implement**: minimal diffs + tests; small stacked PRs (`feat/<slug>-NN`).
- **Evaluate**: evidence → `ADR-###` with ship / iterate / revert decision.

## Stacked PR Etiquette
- 01 base = `main`; 02 base = 01; 03 base = 02, etc.
- Keep each PR 200–400 LOC changed, isolated scope.
- If `main` moves: rebase the whole stack; push with `--force-with-lease`.

## Safety & Quality
- No secrets or placeholders; redact logs.
- No silent breaking changes; version contracts or note migrations + rollback.
- Log structured, leveled events (no secrets). Keep domain logic pure and deterministic.

## Execution
- Run contract tests: `make contracts:test` or `just contracts-test`.
- Respect `.github/PULL_REQUEST_TEMPLATE.md` gates.
