import powerbi from "powerbi-visuals-api";
import { formattingSettings } from "powerbi-visuals-utils-formattingmodel";

class AppearanceCardSettings extends formattingSettings.SimpleCard {
  public showBorder = new formattingSettings.ToggleSwitch({
    name: "showBorder",
    displayName: "Show border",
    value: true
  });

  public accentColor = new formattingSettings.ColorPicker({
    name: "accentColor",
    displayName: "Accent color",
    value: { value: "#3b82f6" }
  });

  public fontSize = new formattingSettings.NumUpDown({
    name: "fontSize",
    displayName: "Font size",
    value: 42,
    options: {
      minValue: {
        type: powerbi.visuals.ValidatorType.Min,
        value: 10
      },
      maxValue: {
        type: powerbi.visuals.ValidatorType.Max,
        value: 96
      }
    }
  });

  public name = "appearance";
  public displayName = "Appearance";
  public topLevelSlice = this.showBorder;
  public slices: formattingSettings.Slice[] = [this.accentColor, this.fontSize];
}

export class VisualFormattingSettingsModel extends formattingSettings.Model {
  public appearance = new AppearanceCardSettings();
  public cards: formattingSettings.SimpleCard[] = [this.appearance];
}
