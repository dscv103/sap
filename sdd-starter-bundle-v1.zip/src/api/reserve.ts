export type BookStatus = 'available' | 'on_hold' | 'checked_out';

export interface Book {
  id: string;
  status: BookStatus;
  holdBy?: string;
}

export interface Patron {
  id: string;
  authenticated: boolean;
}

export interface Db {
  getBook(id: string): Promise<Book | null>;
  setHold(bookId: string, patronId: string): Promise<void>;
}

export type ReserveResult =
  | { ok: true; status: 'On Hold' }
  | { ok: false; error: 'Not available for reservation' | 'Not found' | 'Not authenticated' };

export async function reserveBook(
  args: { bookId: string; patronId: string },
  db: Db,
  patron: Patron
): Promise<ReserveResult> {
  // REQ:101 AC:1 - must require authenticated patron
  if (!patron?.authenticated) {
    return { ok: false, error: 'Not authenticated' };
  }

  const book = await db.getBook(args.bookId);
  if (!book) {
    return { ok: false, error: 'Not found' };
  }

  if (book.status !== 'available') {
    // REQ:101 AC:2 - unavailable => standardized error
    return { ok: false, error: 'Not available for reservation' };
  }

  // Happy path: place the hold
  await db.setHold(book.id, patron.id); // REQ:101 AC:1
  return { ok: true, status: 'On Hold' };
}

export default reserveBook;
