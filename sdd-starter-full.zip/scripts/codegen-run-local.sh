#!/usr/bin/env bash
set -euo pipefail
# codegen-run-local.sh <run-file> [config]
RUN_FILE=${1:?usage: codegen-run-local.sh <runs/a01-analyze.md> [config.example.yaml]}
CFG=${2:-codegen/config.example.yaml}
echo ">>> Run template: $RUN_FILE"
echo ">>> Using config: $CFG"
echo
sed -n '1,200p' "$RUN_FILE"
