# Spec‑Kit (Docs‑only) — Sean Grove‑style workflow + Cursor rules

This is a **drop‑in documentation kit** (no Nix files) to bootstrap a spec‑first, gated workflow for a NixOS configuration.

## Contents
- `./.specify/spec.md` — EARS spec with SLOs, ACs, binary‑cache policy.
- `./.specify/design.md` — Contracts/architecture (docs‑only).
- `./.specify/tasks.md` — Actionable plan (docs‑only).
- `./.specify/memory/constitution.md` — Non‑negotiable policy.
- `./.specify/memory/cursor-rules.md` — Human‑readable cursor rules.
- `./.specify/memory/progress.md` + `cursor.json` — Initialized state.
- `.cursor/rules/spec-kit.mdc` + `repo-context.mdc` — Cursor IDE rules.
- `./.specify/prompts/*.md` — Three operational prompts.

## How to use
1. Commit this folder to the root of your repo.
2. Open Cursor and run `@Cursor Rules` to load project rules.
3. Paste `./.specify/prompts/next-phase.md` to begin at the correct gate.
4. Use `./.specify/prompts/no-repeat-log.md` to keep progress idempotent.
5. When code exists, use `./.specify/prompts/spec-code-gap.md` to audit drift.

> This kit intentionally ships **no .nix files**. Add them in implementation PRs.
