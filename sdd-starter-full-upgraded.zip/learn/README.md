# Learning Records (Self-Learning / Self-Healing)

This folder captures *post-iteration learnings* and *operational signals* that inform the next Analyze phase.

- `records.jsonl`: append-only JSON lines of learning/signals (LRN-###)
- `templates/LRN-000-template.md`: authoring template for structured learning docs

Suggested pipeline:
A) Detect → B) Diagnose → C) Decide → D) Deliver → E) Document & Diffuse
