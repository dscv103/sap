#!/usr/bin/env python
import sys, json, glob
from jsonschema import Draft202012Validator

def main(schema_path, *data_globs):
    with open(schema_path, "r", encoding="utf-8") as f:
        schema = json.load(f)
    validator = Draft202012Validator(schema)
    files = []
    for g in data_globs:
        files.extend(glob.glob(g))
    if not files:
        print("No data files matched.", file=sys.stderr)
        sys.exit(1)
    failures = 0
    for fp in files:
        with open(fp, "r", encoding="utf-8") as f:
            data = json.load(f)
        errors = sorted(validator.iter_errors(data), key=lambda e: e.path)
        if errors:
            failures += 1
            print(f"❌ {fp}")
            for e in errors[:5]:
                loc = ".".join(map(str, e.path)) if e.path else "<root>"
                print(f"  - {loc}: {e.message}")
        else:
            print(f"✅ {fp}")
    sys.exit(1 if failures else 0)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("usage: validate_json.py <schema.json> <data.json...>", file=sys.stderr)
        sys.exit(2)
    main(sys.argv[1], *sys.argv[2:])
