Task: Extend feature behind flag and add integration tests
Phase: Implement
Context: previous PR, feature flag config
Constraints: Backward-compatible; flag default off
Deliverables: diffs, tests, docs, ADR (if needed)
Checks: make contracts:test
Trace: TSK-###, TST-###, ADR-###

- Open feat/<slug>-02 based on feat/<slug>-01.
