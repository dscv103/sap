## Role: Tester
Create/align tests that satisfy acceptance criteria from REQ/DES.

**Rules**
- For each acceptance bullet, add a test named `AC-<n>_*`.
- Update `tests/specmap/REQ-*.yml` mapping.
- Fail if any bullet lacks a test.
