---
id: REQ-000
title: <capability>
phase: Analyze
pattern: When <trigger>, the <system> shall <response> [while <conditions>] [to achieve <goal>].
success_criteria:
  - <latency|accuracy|UX|etc>
non_goals:
  - <explicitly out-of-scope items>
risks_assumptions:
  - <risk or assumption>
examples:
  - Given <state> When <action> Then <observable>
---

## Notes
- Examples should later become tests (`TST-###`).
- Keep capability statements user-observable.
