const path = require("path");
const { PowerBICustomVisualsWebpackPlugin, LocalizationLoader } = require("powerbi-visuals-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const powerbiApi = require("powerbi-visuals-api");

const pbivizPath = "./pbiviz.json";
const pbivizFile = require(path.join(__dirname, pbivizPath));
const capabilitiesPath = "./capabilities.json";
const capabilities = require(path.join(__dirname, capabilitiesPath));
const pluginLocation = "./.tmp/precompile/visualPlugin.ts";
const visualSourceLocation = "../../src/visual";

module.exports = (_env, argv) => {
  const isProduction = argv.mode === "production";

  return {
    entry: {
      "visual.js": pluginLocation
    },
    target: "web",
    mode: isProduction ? "production" : "development",
    devtool: isProduction ? "source-map" : "eval-cheap-module-source-map",
    optimization: {
      minimize: isProduction
    },
    module: {
      rules: [
        {
          test: /\.svelte$/,
          use: {
            loader: "svelte-loader",
            options: {
              compilerOptions: {
                dev: !isProduction
              },
              emitCss: true,
              hotReload: false
            }
          }
        },
        {
          test: /\.ts$/,
          exclude: /node_modules/,
          use: {
            loader: "ts-loader",
            options: {
              transpileOnly: false
            }
          }
        },
        {
          test: /(\.less)|(\.css)$/,
          use: [
            MiniCssExtractPlugin.loader,
            "css-loader",
            {
              loader: "less-loader",
              options: {
                lessOptions: {
                  paths: [path.resolve(__dirname, "node_modules")]
                }
              }
            }
          ]
        },
        {
          test: /\.(woff|ttf|ico|woff2|jpg|jpeg|png|webp|gif|svg|eot)$/i,
          type: "asset/inline"
        },
        {
          test: /powerbiGlobalizeLocales\.js$/,
          loader: LocalizationLoader
        }
      ]
    },
    resolve: {
      alias: {
        svelte: path.dirname(require.resolve("svelte/package.json"))
      },
      conditionNames: ["svelte", "browser", "import", "default"],
      extensions: [".mjs", ".svelte", ".ts", ".js", ".css"],
      mainFields: ["svelte", "browser", "module", "main"]
    },
    externals: {
      "powerbi-visuals-api": "null"
    },
    output: {
      clean: true,
      path: path.join(__dirname, ".tmp", "drop"),
      publicPath: "assets",
      filename: "[name]",
      library: pbivizFile.visual.guid,
      libraryTarget: "var"
    },
    devServer: {
      static: {
        directory: path.join(__dirname, ".tmp", "drop"),
        publicPath: "/assets/"
      },
      compress: true,
      port: 8080,
      hot: false,
      server: {
        type: "https"
      },
      headers: {
        "access-control-allow-origin": "*",
        "cache-control": "public, max-age=0"
      }
    },
    plugins: [
      new MiniCssExtractPlugin({
        filename: "visual.css",
        chunkFilename: "[id].css"
      }),
      new PowerBICustomVisualsWebpackPlugin({
        ...pbivizFile,
        capabilities,
        visualSourceLocation,
        pluginLocation,
        apiVersion: powerbiApi.version,
        capabilitiesSchema: powerbiApi.schemas.capabilities,
        dependenciesSchema: powerbiApi.schemas.dependencies,
        devMode: !isProduction,
        generatePbiviz: isProduction,
        generateResources: isProduction,
        modules: true,
        packageOutPath: path.join(__dirname, "dist")
      })
    ],
    performance: {
      maxEntrypointSize: 1024000,
      maxAssetSize: 1024000
    }
  };
};
