---
id: REQ-000
title: <capability>
phase: Analyze
owner: <name or team>
stakeholders: [<pm>, <design>, <ops>]
date: <YYYY-MM-DD>
links: [DES-###, ADR-###]
---

# Requirements Specification (SDD / The New Code)

## Overview
Brief description of the capability and its value.

## Goals
- Clear, outcome-oriented goals (business/user)

## Non-Goals
- Explicitly out-of-scope items to prevent scope creep

## Success Metrics / SLOs
- Latency: <e.g., p95 ≤ 500ms>
- Reliability: <e.g., error rate ≤ 0.1%>
- Cost/Throughput/UX: <targets>

## Glossary
- Define domain terms the AI/humans must align on.

## Dependencies
- Upstream systems, data feeds, feature flags, migrations

## User Stories & Acceptance Criteria
For each story, include testable acceptance criteria (Given/When/Then). These double as prompts for agents and as tests.

### [REQ-1] <story title>
**Details**: what the system should do (observable behavior only).  
**Acceptance Criteria**
- Given <state> When <action> Then <result>
- Given <edge> When <action> Then <result>

**Trace**
- Tests: TST-###
- Design: DES-###
- Schema: spec/design/schemas/<name>.v1.json

### [REQ-2] <story 2>
<...>

## Constraints
- Performance / regulatory / platform constraints

## Telemetry
- Events, logs, metrics required to validate SLOs

## Risks & Mitigations
- Enumerate risks with mitigation strategies

## Open Questions
- Items needing product/tech decisions

## Test Plan (from Acceptance Criteria)
- Unit/contract/integration outline; who/what runs them
