# Codegen Agent Wiring (Claude 4 Sonnet)

This folder integrates your SDD scaffold with **Codegen** agents using **Claude 4 Sonnet**.
- Agent reads repo **rules** and **SDD artifacts** automatically when the active codebase is set.
- Use the provided **run templates** to kick off Analyze/Design/Implement/Evaluate tasks.
- PR flow uses **stacked branches** created with pure git (see `scripts/stack/*`).

## Files
- `agent.md` — high-level role, capabilities, constraints
- `rules.md` — enforced repo guardrails (mirrors REPO_RULES + SDD)
- `config.example.yaml` — example model + behavior toggles
- `runs/` — ready-to-fill run prompts (`a01`..`a05`) with SDD headers
- `SETUP.md` — sandbox Setup Commands (paste into Codegen settings)
- `RUNBOOK.md` — single-page end-to-end flow
- `../.github/workflows/contracts-test.yml` — CI gate

## Usage
1. Copy/adjust `config.example.yaml` to your workspace model naming if needed.
2. Start with `runs/a01-analyze.md` to seed **Analyze**; move to a fresh run for **Implement**.
3. Verify locally: `make contracts:test` or `just contracts-test`.
4. Submit as **stacked PRs**: 01→main, 02→01, etc.
