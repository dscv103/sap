# Schemas

Place JSON Schema / IDL specs here. Treat schemas as contracts.

- Keep them versioned.
- Add contract tests in `spec/tests/contracts/`.
