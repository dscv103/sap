#!/usr/bin/env bash
set -euo pipefail
# stack-new <slug> [NN] [base]
slug=${1:?usage: stack-new <slug> [NN] [base]}
idx=${2:-01}
base=${3:-origin/main}
branch="feat/${slug}-${idx}"
git fetch origin
git checkout -B "${branch}" "${base}"
echo "Created ${branch} from ${base}"
