# [DES-101] Reservation Design

**Maps to:** REQ-101

## Architecture
- Module `src/api/reserve.ts` exposes a pure function `reserveBook` for core logic.
- HTTP layer to be added in later slices.

## Data Model (logical)
```
Book: { id: string, status: 'available' | 'on_hold' | 'checked_out', holdBy?: string }
Patron: { id: string, authenticated: boolean }
```

## Contract
```
reserveBook(args: { bookId: string, patronId: string }, db: Db) =>
  { ok: true, status: 'On Hold' } |
  { ok: false, error: 'Not available for reservation' | 'Not found' | 'Not authenticated' }
```

- Side effects:
  - Set hold to patron if available.
  - Do not mutate when unavailable.

## Minimal Slices
1. **TSK-101-01:** Happy path + unavailable error (AC-1 & AC-2) with pure function + unit tests.
2. **TSK-101-02:** Add simple audit logging wrapper.
3. **TSK-101-03:** Add 24h hold expiry (future REQ).

## Non-functional
- Deterministic function (easy to test).
- No external IO in the first slice.
