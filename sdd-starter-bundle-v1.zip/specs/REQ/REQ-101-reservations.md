# [REQ-101] User Reservation Feature

**Overview:** Patron reserves a book online and picks it up later.

**Goals**
- Allow authenticated patrons to place a hold on an available book.
- Prevent reservations for unavailable books (on hold or checked out).

**User Stories & Requirements**
1. **Reserve available book**
   - *Details:* System accepts `bookId` and `patronId`. If book is `available`, place hold for patron.
   - *Acceptance Criteria:*
     - AC-1: *Given* an available book and an authenticated patron, *when* the patron clicks "Reserve", *then* the book’s status becomes "On Hold" under that patron’s account.
     - AC-2: *Given* a book already on hold or checked out, *when* a patron attempts to reserve it, *then* the system shows an error "Not available for reservation."

**Constraints**
- Keep operation idempotent per patron/book pair.
- Log reservation attempts.

**Success Metrics**
- >= 95% successful holds for available books; error rate aligns with inventory state.

**Test Plan**
- Unit tests mirror AC-1 and AC-2.
- Integration tests later when HTTP API is added.
