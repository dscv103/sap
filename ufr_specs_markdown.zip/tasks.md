# UFR — Tasks & Plan (Final)

## RACI
- R: Primary implementer
- A: Tech Lead
- C: QA, Security
- I: DevEx

## Tasks

| ID      | Task                                                                 | Depends On     | R | A | C        | I    | Acceptance Criteria |
|---------|----------------------------------------------------------------------|----------------|---|---|----------|------|---------------------|
| T-0001  | Project scaffolding + `pyproject.toml` + console script              | —              | R | A | —        | DevEx | `ufr --version` prints version |
| T-0002  | CLI → `Config` (all flags, help text, examples)                      | T-0001         | R | A | QA       | —    | Flags parse; `--help` shows all |
| T-0003  | Discovery (paths/dirs, recursive, include/exclude, symlink policy)   | T-0002         | R | A | QA       | —    | Recursion & glob tests pass |
| T-0004  | Date parsing (ISO, compact, DMY opt-in) + strict validation          | T-0002         | R | A | QA       | —    | Leap & invalid dates handled |
| T-0005  | Timestamp fallback (mtime/ctime, local/UTC)                          | T-0004         | R | A | QA       | —    | Deterministic outputs |
| T-0006  | Slugifier (NFC, ASCII-fold, rules, fallback)                         | T-0002         | R | A | QA       | —    | Table tests pass |
| T-0007  | Multi-part extension resolver & case modes                           | T-0002         | R | A | QA       | —    | Known set + additive flag |
| T-0008  | Target builder + idempotency detection                               | T-0004..7      | R | A | QA       | —    | Normalized check & `--force` |
| T-0009  | Collision policies (dedup/skip/overwrite)                            | T-0008         | R | A | QA       | —    | `-N` numbering; skip/overwrite |
| T-0010  | Executor (atomic rename, fsync, Win case-only two-step)              | T-0009         | R | A | QA, Sec  | —    | E2E safe rename on all OSes |
| T-0011  | Reporter (plain/json), quiet/verbose, durations                      | T-0009         | R | A | QA       | —    | Schema validated; samples match |
| T-0012  | `--confirm` preflight summary                                        | T-0003..11     | R | A | QA       | —    | Decline aborts; accept proceeds |
| T-0013  | Cross-platform filename safety & reserved names                       | T-0008         | R | A | QA, Sec  | —    | Forbidden chars & names handled |
| T-0014  | Coverage ≥85% across suites                                          | T-0002..13     | R | A | QA       | —    | Coverage report ≥85% |
| T-0015  | Performance check (≤200ms/file local)                                | T-0009..11     | R | A | QA       | —    | Bench meets budget |
| T-0016  | Documentation polish & examples                                      | T-0011         | R | A | DevEx    | I    | Examples mirror behavior |

## Sequencing
Bootstrap → CLI → Planning primitives → Naming & collisions → Executor & safety → Reporting/UX → Tests/perf → Docs.

## Acceptance Criteria (Global)
- All R-IDs have passing tests; coverage ≥85%.
- Performance: median ≤200ms per file on local SSD.
- Cross-platform safety suite green.
- Examples in help and README reproduce exactly.
