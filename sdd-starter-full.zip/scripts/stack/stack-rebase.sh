#!/usr/bin/env bash
set -euo pipefail
# stack-rebase <slug> [base=origin/main] [from=01] [to=20]
slug=${1:?usage: stack-rebase <slug> [base] [from] [to]}
base=${2:-origin/main}
from=${3:-01}; to=${4:-20}
git fetch origin
prev="${base}"
for i in $(seq -w ${from} ${to}); do
  b="feat/${slug}-${i}"
  if git show-ref --verify --quiet "refs/heads/${b}"; then
    echo "Rebasing ${b} onto ${prev}"
    git checkout "${b}"
    git rebase "${prev}"
    prev="${b}"
  fi
done
echo "Remember to push with --force-with-lease as needed."
