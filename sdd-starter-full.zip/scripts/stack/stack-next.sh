#!/usr/bin/env bash
set -euo pipefail
# stack-next <slug> [prevNN]
slug=${1:?usage: stack-next <slug> [prevNN]}
prev=${2:-01}
next=$(printf "%02d" $((10#$prev + 1)))
prev_branch="feat/${slug}-${prev}"
next_branch="feat/${slug}-${next}"
git checkout -B "${next_branch}" "${prev_branch}"
echo "Created ${next_branch} from ${prev_branch}"
