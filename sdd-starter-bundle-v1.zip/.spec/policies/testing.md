# Testing Policy
- Unit tests mirror acceptance bullets one-to-one.
- Name tests `AC-<n>_*` and map them in `tests/specmap/REQ-*.yml`.
- Include negative-path tests where applicable.
