---
title: "Unified File Renamer (UFR)"
version: "1.0.1"
owner: "Core Tools Team"
stakeholders: ["DevEx","Content Ops","Security"]
audience: ["Engineers","QA","SRE"]
status: "Final"
tooling:
  language: "Python 3.13"
  stdlib_only: true
  typing: "PEP 695 / typing + pathlib"
environments:
  os: ["Linux","macOS","Windows"]
  fs: ["POSIX","NTFS","HFS+","APFS"]
non_functional:
  perf_budget_ms_local: 200
  memory_mb: 64
  path_segment_max_bytes: 255
  coverage_min_pct: 85
compliance:
  filenames_safe: true
  symlinks_followed_by_default: false
  atomic_rename_where_supported: true
  windows_case_only_two_step: true
---

# EARS Requirements
... (content from final requirements.md above) ...
