# NixOS Configuration — Spec (flake-parts, EARS, feature-driven)

**Owner:** Derek  
**Host target:** x86_64-linux (desktop/workstation)  
**Primary machine:** `blazar` (Ryzen 7 5900X, NVIDIA GTX 970, **64 GB RAM**, 1 TB Seagate FireCuda NVMe)  
**Locale/TZ:** `en_US.UTF-8`, `America/Chicago`  
**Connectivity policy:** Wired-only Ethernet; **no Wi‑Fi**, **no Bluetooth**  
**Spec status:** v1.5 — *Spec‑only repo kit (no code)*

**Governance references**
- `constitution_ref`: `./.specify/memory/constitution.md` (G0)  
- `cursor_rules_ref`: `.cursor/rules/*.mdc`

---

## 0) Purpose & Scope

This spec defines the required behavior of a reproducible NixOS workstation implemented via **flake‑parts**, with encrypted **bcachefs**, **latest stable Linux kernel**, NVIDIA graphics, GNOME on **Wayland**, developer UX (VS Code with user‑mutable settings, Python, dev shells, direnv), Zsh + Starship, Ghostty terminal, **substitution‑first builds via binary caches**, and wired‑only networking.

> This kit ships **only documentation and rules** (no Nix files). It is meant to be dropped into a repo **before** implementation begins.

---

## 0.1 Success Metrics (SLOs)

- **SLO‑1:** First `nixos‑rebuild switch` ≤ **25 min**; incremental ≤ **8 min**.  
- **SLO‑2:** Cold boot to GNOME login ≤ **45 s** on NVMe.  
- **SLO‑3:** Idle desktop RAM ≤ **2.5 GiB** post‑login.  
- **SLO‑4:** Wayland session + NVIDIA healthy (`nvidia‑smi`).  
- **SLO‑5:** All AC probes pass in CI and on hardware.  
- **SLO‑6:** **≥ 0.80 substitution rate** on clean CI (binary‑cache first).

---

## 0.2 Gates & Approvals (Sean‑Grove‑style)

Gated flow: **G0 → G1 → G1.5 → G2 → G3 → G3.5 → G4**

- **G0 — Constitution Gate**: This constitution exists; approvals template attached.  
- **G1 — Spec Freeze (this file)**: REQs + ACs + SLOs complete. Tag `spec/vX.Y`.  
- **G1.5 — Clarify**: Questions resolved; ADRs opened for trade‑offs.  
- **G2 — Plan Freeze**: `design.md` + `tasks.md` ready.  
- **G3 — Analysis & Checklist**: Coverage + quality checks green.  
- **G3.5 — Implement**: Handoff to implementation; run log captured.  
- **G4 — Release**: Bundle with provenance + rollback.

**Approvals** per gate: Owner + Reviewer (Ops added at G2/G4).

---

## 1) Method & Notation

- **EARS** requirement styles: Ubiquitous (“The system shall …”), Event‑driven (“When …”), State‑driven (“While …”), Optional, Unwanted.  
- **IDs:** `REQ‑<FEATURE>‑NNN`. Each REQ has **Acceptance Criteria (AC)**.

---

## 2) Overview (what must be true)

- **Pinning**: `nixpkgs` source is **nixpkgs‑unstable**, **pinned**.  
- **Kernel**: **latest stable** kernel (at pinned input).  
- **Desktop**: GNOME on **Wayland** (+ XWayland).  
- **Shell/Prompt**: Zsh + Starship. **Terminal**: Ghostty.  
- **Dev UX**: VS Code (user‑mutable `settings.json`), Python, dev shells, direnv.  
- **Networking**: Ethernet only; firewall default‑deny inbound; Wi‑Fi/BT disabled.  
- **Binary cache**: **Substitution‑first** with official cache + keys.  
- **Home**: User `derek` managed (via HM in implementation).

---

## 3) Global Requirements

### 3.1 Reproducibility
- **REQ‑GLOBAL‑001 (Ubiquitous):** Use **flakes** + **flake‑parts**; no channels.  
- **REQ‑GLOBAL‑002 (Ubiquitous):** Pin **nixpkgs‑unstable** in `flake.lock`.  
- **REQ‑GLOBAL‑003 (Unwanted):** No `nix‑env -i` or mutable global installs.

**AC**: `flake.lock` pins nixpkgs; `nix flake check` green.

### 3.2 Locale & Time
- **REQ‑LOCALE‑001:** `en_US.UTF‑8`.  
- **REQ‑LOCALE‑002:** `America/Chicago` time zone.

**AC**: `locale` and `timedatectl` reflect values.

### 3.3 Binary Cache (Substitution‑first)
- **REQ‑BINCACHE‑001:** Enable **substituters**; prefer download over compile.  
- **REQ‑BINCACHE‑002:** Include `https://cache.nixos.org/`.  
- **REQ‑BINCACHE‑003:** Trust key `cache.nixos.org-1:` (+ any ADR‑approved).  
- **REQ‑BINCACHE‑004 (Unwanted):** Do not disable substituters/signature checks.

**AC**: `nix show-config` lists substituters & keys; **SLO‑6** met.

---

## 4) Feature Requirements (EARS)

### F0 — Kernel & Base
- **REQ‑KERNEL‑001:** Use **latest stable** kernel at pin.  
- **REQ‑KERNEL‑002 (Event):** On pin bump, upgrade kernel.  
- **REQ‑KERNEL‑003 (Unwanted):** No silent LTS pins (ADR required for exceptions).

**AC**: `uname -r` matches latest at pin; boots cleanly.

### F1 — Storage & Boot
- **REQ‑FS‑001:** LUKS‑encrypted root.  
- **REQ‑FS‑002:** Root **bcachefs**.  
- **REQ‑FS‑003:** **systemd‑boot** (EFI).  
- **REQ‑FS‑004 (Unwanted):** No unencrypted system partitions.

**AC**: `lsblk`, `mount`, `bootctl status` reflect targets.

### F2 — Desktop
- **REQ‑DESK‑001:** GNOME **Wayland** default; **XWayland** for legacy apps.  
- **REQ‑DESK‑002 (Unwanted):** No default Xorg session.

**AC**: `$XDG_SESSION_TYPE=wayland`; legacy X11 apps run via XWayland.

### F3 — NVIDIA
- **REQ‑GPU‑001:** Proprietary NVIDIA driver.  
- **REQ‑GPU‑002:** Vulkan available.  
- **REQ‑GPU‑003 (Unwanted):** No DKMS/manual drivers.

**AC**: `nvidia‑smi` works; `vulkaninfo` lists NVIDIA ICD.

### F4 — Networking
- **REQ‑NET‑001:** Ethernet only; firewall default‑deny inbound.  
- **REQ‑NET‑002 (Unwanted):** Wi‑Fi disabled.  
- **REQ‑NET‑003 (Unwanted):** Bluetooth disabled.

**AC**: Radios blocked; Ethernet managed; firewall active.

### F5 — Audio
- **REQ‑AUDIO‑001:** PipeWire + WirePlumber; no standalone PulseAudio.

**AC**: User units active; conferencing apps see devices.

### F6 — Dev UX
- **REQ‑DEV‑001:** VS Code installed; **`settings.json` stays user‑mutable** from the app UI.  
- **REQ‑DEV‑002:** Python toolchain + **dev shells** + **direnv**.  
- **REQ‑DEV‑003 (Unwanted):** No global mutable site‑packages.

**AC**: UI tweaks persist; `nix develop` + `direnv` function (in implementation).

### F7 — Shell & Terminal
- **REQ‑SHELL‑001:** Zsh default; **Starship** prompt.  
- **REQ‑TERM‑001:** **Ghostty** default terminal (GNOME bound).

**AC**: `$SHELL=zsh`; `starship --version`; Ghostty opens by default.

### F8 — Security, Observability, Backup (selected)
- **REQ‑SEC‑001:** No plaintext secrets in repo; sops‑nix if secrets appear (ADR).  
- **REQ‑OBS‑001:** `journald` with sane rotation; optional persistence.  
- **REQ‑BKP‑001 (Optional):** Snapshot/backup strategy documented.

---

## 5) Evaluation Harness (concept)

- **REQ‑EVAL‑001:** A scriptable probe suite shall verify ACs and compute **substitution rate** from logs.  
- **REQ‑EVAL‑002:** CI shall block merges if ACs/SLOs fail.

**AC**: `report.json` emitted with AC statuses + `substitution_rate` (when implementation exists).

---

## 6) Risks (selected)

- Latest kernel breaks NVIDIA (mitigate: ADR + temporary LTS pin + rollback).  
- bcachefs regression (mitigate: pin, snapshot, ADR).  
- VS Code settings overwritten accidentally (mitigate: test/policy).

---

## 7) Non‑Goals

- Wi‑Fi & Bluetooth.  
- Multi‑user beyond `derek`.  
- Xorg as primary session.

---

## 8) Acceptance Criteria Summary

- Reproducible flake build; nixpkgs from **unstable**, **pinned**.  
- Latest stable kernel.  
- Encrypted bcachefs root; systemd‑boot.  
- GNOME Wayland + XWayland.  
- NVIDIA & Vulkan OK.  
- PipeWire OK.  
- Ethernet‑only; Wi‑Fi/BT disabled.  
- VS Code **user‑mutable settings**; dev shells + direnv.  
- Zsh + Starship; Ghostty default terminal.  
- **Binary‑cache substitution ≥ 0.80** (clean CI).  
- CI probes pass; approvals present.
