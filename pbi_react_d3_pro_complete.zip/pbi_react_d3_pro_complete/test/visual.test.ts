describe('Visual', () => {
  it('initializes', () => {
    expect(true).toBe(true);
  });
});