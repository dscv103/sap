<script>
  let { stateStore } = $props();
</script>

<div
  class="metric-card"
  class:bordered={$stateStore.showBorder}
  class:empty={!$stateStore.hasData}
  style={`--accent:${$stateStore.accentColor}; --font-size:${$stateStore.fontSize}px;`}
>
  <div class="metric-card__eyebrow">Svelte 5 custom visual</div>
  <div class="metric-card__title">{$stateStore.title}</div>
  <div class="metric-card__value">{$stateStore.value}</div>
  {#if $stateStore.footnote}
    <div class="metric-card__footnote">{$stateStore.footnote}</div>
  {/if}
</div>

<style>
  .metric-card {
    width: 100%;
    height: 100%;
    box-sizing: border-box;
    padding: 18px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 8px;
    border-radius: 12px;
    background: #ffffff;
    color: #111827;
    overflow: hidden;
  }

  .metric-card.bordered {
    border: 1px solid #d1d5db;
    box-shadow: inset 4px 0 0 0 var(--accent);
  }

  .metric-card.empty {
    background: #f9fafb;
    color: #6b7280;
  }

  .metric-card__eyebrow {
    font-size: 11px;
    line-height: 1.2;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: var(--accent);
    font-weight: 700;
  }

  .metric-card__title {
    font-size: 14px;
    line-height: 1.3;
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .metric-card__value {
    font-size: var(--font-size);
    line-height: 1;
    font-weight: 700;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .metric-card__footnote {
    font-size: 12px;
    line-height: 1.4;
    color: #6b7280;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
