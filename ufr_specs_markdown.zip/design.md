# UFR — Design (Final)

## 1. Purpose & Scope
Normalize filenames to `YYYY-MM-DD_slug.ext` with predictable rules, cross-platform safety, and deterministic planning, implemented in Python 3.13 with stdlib only by default.

## 2. Architecture
```
[CLI] -> [Discovery] -> [Plan(Date,Slug,Ext,Target,Collision)] -> [Executor] -> [Reporter]
```

### Modules
- `ufr/__main__.py` — entry point
- `ufr/cli.py` — argparse → `Config`
- `ufr/discover.py` — yield candidate files
- `ufr/plan.py` — date parsing, slugify, ext resolve, target build, collision
- `ufr/exec.py` — safe/atomic renames
- `ufr/report.py` — plain/json emit
- `ufr/types.py` — dataclasses & type aliases
- `tests/` — unit tests

## 3. Interfaces (Python 3.13 typed)
```python
def parse_args(argv: list[str]) -> Config: ...
def discover(cfg: Config) -> Iterable[Path]: ...
def resolve_date(name: str, p: Path, cfg: Config) -> tuple[str, DateSource] | None: ...
def slugify(text: str) -> tuple[str, SlugSource]: ...
def resolve_extension(p: Path, cfg: Config) -> str: ...
def build_target(date: str, slug: str, ext: str) -> str: ...
def is_normalized(name: str, known_multi_exts: list[str]) -> bool: ...
def resolve_collision(dir_: Path, stem: str, ext: str, policy: CollisionPolicy) -> str | None: ...
def execute_rename(src: Path, dst: Path, cfg: Config) -> None: ...
def emit(op: OperationReport, mode: StdoutMode) -> None: ...
```

## 4. Algorithms & Rules
- **Date Regexes**: ISO / compact / DMY (opt-in), each validated via `datetime.date`.
- **Slugification**: NFC → lower → ASCII-fold (incl. `ß→ss`, `œ→oe`) → `&→and` → ws/`_`→`-` → drop invalid → collapse → trim → fallback.
- **Extensions**: maintain longest matching multi-ext from known set; apply `--add-multi-ext` additions; case-fold per `--ext-case`.
- **Collisions**: if `dedup`, increment `-N` before ext until free; if `skip`, mark and report; if `overwrite`, replace.
- **Idempotency**: detect already normalized; skip unless `--force`.
- **Safety**: do not follow symlinks unless flagged; Windows case-only two-step; fsync dir on rename where feasible.

## 5. Data Model
`Config`, `OperationReport` as specified; JSON schema pinned in Requirements §Reporting.

## 6. Trade-offs
Stdlib portability vs. convenience; opt-in features to preserve determinism; no metadata parsing beyond filename/timestamps.

## 7. Testing Plan
- Unit tests per component + E2E on temp dirs.
- Platform-specific tests behind markers (Windows case-only behavior).
- Coverage target ≥85%.

## 8. Non-Functional Targets
- ≤200ms per file local baseline.
- Memory ≤64MB typical runs.
- Path segment ≤255 bytes enforced.
