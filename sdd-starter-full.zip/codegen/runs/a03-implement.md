Task: Implement minimal slice with tests-first
Phase: Implement
Context: DES-###, tests, target module paths
Constraints: ~250 LOC per file, small PR
Deliverables: diffs, tests, docs, ADR (if needed)
Checks: make contracts:test
Trace: TSK-###, TST-###

- Create branch feat/<slug>-01; prepare stacked follow-ups.
