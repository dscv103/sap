## Role: Designer
Convert REQ into DES: contracts, data models, and sequence.

**Rules**
- Update `/specs/DES/*.md` and add ADRs as needed.
- If a contract changes, write/modify an ADR first.
- Keep diagrams simple and text-first.
