#!/usr/bin/env bash
set -euo pipefail

if ! command -v yq >/dev/null 2>&1; then
  echo "yq is required. Install yq (e.g., 'sudo dnf install yq' on Fedora)." >&2
  exit 1
fi

missing=0

# Ensure every REQ has 'Acceptance Criteria' and is referenced by some DES
while IFS= read -r req; do
  id=$(basename "$req" .md | cut -d'-' -f2)
  if ! grep -q "Acceptance Criteria" "$req"; then
    echo "❌ $req: missing 'Acceptance Criteria' section"; missing=1
  fi
  if ! grep -Rqs "REQ-${id}" specs/DES; then
    echo "❌ REQ-${id}: no DES referencing this requirement"; missing=1
  fi
done < <(find specs/REQ -name "REQ-*.md" -print)

# Ensure each specmap has tests
while IFS= read -r map; do
  tests=$(yq '.tests | length' "$map")
  if [ "$tests" -eq 0 ]; then
    echo "❌ $map: no tests mapped"; missing=1
  fi
done < <(find tests/specmap -name "REQ-*.yml" -print)

if [ "$missing" -ne 0 ]; then
  echo "Spec lint FAILED"; exit 1
else
  echo "✅ Spec lint passed"
fi
