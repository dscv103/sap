# ADR-001: Persistence Approach (Early Slices)

**Context**
We need to manage reservations. Options: in-memory, Postgres table, separate service.

**Decision**
Start with an abstract `Db` contract to keep logic pure; wire to actual persistence later.

**Status**
Accepted (2025-11-03)

**Justification**
Keeps early slices testable and portable. Real DB wiring can be postponed until HTTP/API integration.

**Consequences**
- Must implement `Db` later; unit tests use a fake.
