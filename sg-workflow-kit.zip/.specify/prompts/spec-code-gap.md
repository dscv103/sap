You are performing a drift audit between the spec and the implementation.

Goal: Find gaps between ./.specify/spec.md (REQs/ACs) and the code/config, and between ACs and tests. Do not guess; mark unknowns explicitly.

Method:
1) Parse all REQ-* IDs from the spec and build a table: REQ_ID, Section, Short Name, ACs.
2) From design.md, map REQ_ID → Modules → Exposed options (planned).
3) From code (if present), verify those options exist; record status: {present|missing|unknown}.
4) From tests (if present), verify each AC has a probe/check; map AC → evidence.
5) Emit THREE reports:
   a) Coverage Matrix (Markdown)
   b) Gaps List (reqs without code; reqs without tests; orphan tests)
   c) Machine JSON at ./.specify/tests/gap_report.json (missing_code, missing_tests, orphan_tests)
6) Propose minimal diffs (paths + snippets) to close each gap.
7) Finish with a Stoplight summary: Green/Yellow/Red/Unknown.

Output:
- Brief summary
- Coverage Matrix
- Gaps List
- JSON contents
- Next actions
