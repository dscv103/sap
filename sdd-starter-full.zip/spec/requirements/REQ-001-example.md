---
id: REQ-001
title: User can export report as JSON
phase: Analyze
pattern: When a user requests an export from the reports page, the system shall generate a JSON file for the selected report while preserving user filters.
success_criteria:
  - Export completes within 5s for 10k-row reports
  - Output validates against `DES-101` JSON Schema
non_goals:
  - PDF export (tracked separately)
risks_assumptions:
  - Large reports may require async processing
examples:
  - Given a filtered report of 100 rows When user clicks "Export JSON" Then a JSON file downloads matching the filter
---
