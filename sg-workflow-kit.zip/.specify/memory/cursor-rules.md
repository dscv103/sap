# Cursor Rules — Spec‑Kit Workflow (G0 → G4)

**Authoritative files**  
- Cursor state: `./.specify/memory/cursor.json`  
- Progress log: `./.specify/memory/progress.md`  
- Constitution: `./.specify/memory/constitution.md`  
- Spec/Plan/Tasks: `./.specify/{spec.md,design.md,tasks.md}`

**Timezone:** America/Chicago (ISO‑8601)

## 1) Cursor JSON — Schema
```json
{
  "gate": "G0|G1|G1.5|G2|G3|G3.5|G4",
  "status": "clean|dirty",
  "last_action": "short, imperative phrase",
  "artifacts": ["relative/path"],
  "blockers": ["..."],
  "next_hint": "one‑line next step",
  "last_action_sha": "<sha256(gate + last_action + artifacts[])>",
  "updated_at": "YYYY‑MM‑DDTHH:MM:SS‑05:00",
  "gate_history": [ {"gate":"G0","at":"…","sha":"…"} ]
}
```

## 2) Gate Detection (artifact truth table)
- **G0**: `constitution.md` exists.  
- **G1**: `spec.md` exists and includes “Acceptance Criteria Summary”.  
- **G1.5**: `clarify.md` exists.  
- **G2**: `design.md` and `tasks.md` exist.  
- **G3**: coverage/checklist artifacts exist (during implementation).  
- **G3.5**: implement run log exists.  
- **G4**: release bundle manifest exists.

## 3) Idempotency & Monotonicity
- Recompute `last_action_sha`; if unchanged, **do not** append logs (“No change”).  
- Gates only advance forward; rollbacks require an ADR.

## 4) Progress Log (append‑only)
```
### <timestamp> — <GATE> — <last_action>
Artifacts:
- <path>
Blockers:
- <text>
Next:
- <next_hint>
```

## 5) Agent Loop (exact)
1. Read/create cursor; detect current gate from artifacts.  
2. Verify preconditions for **next** gate; if missing → mark **dirty** and STOP.  
3. Plan concrete shell commands (do not execute).  
4. Append to progress (if new) + update cursor atomically.  
5. Output decision + commands + next_hint.
