#!/usr/bin/env bash
set -euo pipefail
# stack-submit <slug> [from=01] [to=20]
slug=${1:?usage: stack-submit <slug> [from] [to]}
from=${2:-01}; to=${3:-20}
for i in $(seq -w ${from} ${to}); do
  b="feat/${slug}-${i}"
  if git show-ref --verify --quiet "refs/heads/${b}"; then
    echo "Pushing ${b}"
    git push -u origin "${b}"
  fi
done
echo "Create PRs in GitHub UI with bases chained 01→02→03…"
