import powerbi from "powerbi-visuals-api";
import { FormattingSettingsService } from "powerbi-visuals-utils-formattingmodel";
import { mount, unmount } from "svelte";
import { writable, type Writable } from "svelte/store";

import App from "./App.svelte";
import { VisualFormattingSettingsModel } from "./settings";
import "../style/visual.less";

import DataView = powerbi.DataView;
import IVisual = powerbi.extensibility.visual.IVisual;
import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;

interface VisualState {
  hasData: boolean;
  title: string;
  value: string;
  footnote: string;
  accentColor: string;
  fontSize: number;
  showBorder: boolean;
}

const DEFAULT_STATE: VisualState = {
  hasData: false,
  title: "No data",
  value: "—",
  footnote: "Bind a measure to Value and optionally a field to Category.",
  accentColor: "#3b82f6",
  fontSize: 42,
  showBorder: true
};

export class Visual implements IVisual {
  private readonly hostElement: HTMLElement;
  private readonly stateStore: Writable<VisualState>;
  private readonly formattingSettingsService: FormattingSettingsService;
  private formattingSettings: VisualFormattingSettingsModel;
  private app: Record<string, any> | undefined;

  constructor(options: VisualConstructorOptions) {
    this.hostElement = document.createElement("div");
    this.hostElement.className = "svelte-visual-host";
    options.element.appendChild(this.hostElement);

    this.stateStore = writable(DEFAULT_STATE);
    this.formattingSettingsService = new FormattingSettingsService();
    this.formattingSettings = new VisualFormattingSettingsModel();

    this.app = mount(App, {
      target: this.hostElement,
      props: {
        stateStore: this.stateStore
      }
    }) as Record<string, any>;
  }

  public update(options: VisualUpdateOptions): void {
    this.formattingSettings = this.formattingSettingsService.populateFormattingSettingsModel(
      VisualFormattingSettingsModel,
      options.dataViews ?? []
    );

    const viewModel = this.buildViewModel(options.dataViews?.[0]);
    const appearance = this.formattingSettings.appearance;

    this.stateStore.set({
      ...viewModel,
      accentColor: appearance.accentColor.value.value,
      fontSize: Number(appearance.fontSize.value),
      showBorder: Boolean(appearance.showBorder.value)
    });
  }

  public getFormattingModel(): powerbi.visuals.FormattingModel {
    return this.formattingSettingsService.buildFormattingModel(this.formattingSettings);
  }

  public destroy(): void {
    if (this.app) {
      void unmount(this.app);
      this.app = undefined;
    }
  }

  private buildViewModel(dataView: DataView | undefined): VisualState {
    if (!dataView) {
      return DEFAULT_STATE;
    }

    const categoryColumn = dataView.categorical?.categories?.[0];
    const valueColumn = dataView.categorical?.values?.[0];
    const metadataValueColumn = dataView.metadata?.columns?.find((column) => column.roles?.value) ?? valueColumn?.source;

    const categoryLabel = categoryColumn?.values?.[0];
    const rawValue = valueColumn?.values?.[0] ?? dataView.single?.value;

    if (rawValue === null || rawValue === undefined) {
      return DEFAULT_STATE;
    }

    const categoryName = categoryColumn?.source?.displayName ?? "";
    const measureName = metadataValueColumn?.displayName ?? "Value";
    const rowCount = categoryColumn?.values?.length ?? 1;

    return {
      hasData: true,
      title: categoryLabel !== undefined && categoryLabel !== null ? String(categoryLabel) : measureName,
      value: this.formatValue(rawValue),
      footnote: categoryName
        ? `${categoryName} · ${measureName}${rowCount > 1 ? ` · ${rowCount} rows` : ""}`
        : measureName,
      accentColor: DEFAULT_STATE.accentColor,
      fontSize: DEFAULT_STATE.fontSize,
      showBorder: DEFAULT_STATE.showBorder
    };
  }

  private formatValue(value: unknown): string {
    if (typeof value === "number") {
      return new Intl.NumberFormat(undefined, {
        maximumFractionDigits: 2
      }).format(value);
    }

    if (value instanceof Date) {
      return value.toLocaleDateString();
    }

    return String(value);
  }
}
