---
title: "Unified File Renamer (UFR)"
version: "1.0.1"
owner: "Core Tools Team"
stakeholders: ["DevEx","Content Ops","Security"]
audience: ["Engineers","QA","SRE"]
status: "Final"
tooling:
  language: "Python 3.13"
  stdlib_only: true
  typing: "PEP 695 / typing + pathlib"
environments:
  os: ["Linux","macOS","Windows"]
  fs: ["POSIX","NTFS","HFS+","APFS"]
non_functional:
  perf_budget_ms_local: 200
  memory_mb: 64
  path_segment_max_bytes: 255
  coverage_min_pct: 85
compliance:
  filenames_safe: true
  symlinks_followed_by_default: false
  atomic_rename_where_supported: true
  windows_case_only_two_step: true
---

# EARS Requirements

## Language & Standards
- **R-0001 (UBIQUITOUS)** — THE SYSTEM SHALL be implemented in Python 3.13 with explicit typing and `pathlib` for all paths; `from __future__ import annotations` MUST be present in each module. Verify: `test_env_python_version`, `test_typing_enforced`.
- **R-0002 (UBIQUITOUS)** — THE SYSTEM SHALL rely only on the standard library by default; any optional dependency MUST be behind a feature flag that is OFF by default. Verify: `test_no_third_party_by_default`.

## Program Name & Entry
- **R-0010 (UBIQUITOUS)** — THE SYSTEM SHALL expose a console script `ufr` bound to `ufr.__main__:main`. Verify: `test_entry_point_resolution`.

## Target Naming
- **R-0100 (UBIQUITOUS)** — THE SYSTEM SHALL output names in the exact form `YYYY-MM-DD_${slug}${ext}` where `${slug} ∈ [a-z0-9-]+` and `${ext}` preserves multi-part extensions. Verify: `test_target_format_basic`.
- **R-0101 (UBIQUITOUS)** — THE SYSTEM SHALL preserve multi-part extensions and, unless configured `--ext-case=preserve`, fold to lower. Verify: `test_multi_part_extension`, `test_ext_case_modes`.
- **R-0102 (UNWANTED)** — IF computed name equals the current name and `--force` is not set THEN THE SYSTEM SHALL set `action=skipped` with `reason=idempotent`. Verify: `test_idempotency_skip`.

## Slugification
- **R-0200 (UBIQUITOUS)** — THE SYSTEM SHALL perform NFC normalization, lowercase, ASCII-fold (`é→e`,`ø→o`,`ß→ss`,`œ→oe`), replace `&`→`and`, replace whitespace/underscore→`-`, remove `[^a-z0-9-]`, collapse `-+`, trim, and fallback to `file` if empty. Verify: `test_slugify_*`.
- **R-0201 (UNWANTED)** — IF slug becomes empty THEN THE SYSTEM SHALL set `slug_source=fallback`. Verify: `test_slugify_empty_fallback`.

## Date Determination
- **R-0300 (EVENT)** — WHEN `--date YYYY-MM-DD` is provided, THE SYSTEM SHALL strictly validate the date (Gregorian calendar; leap years) and reject invalid input with `action=error`. Verify: `test_date_cli_override_*`.
- **R-0301 (EVENT)** — WHEN parsing from filename, THE SYSTEM SHALL search patterns in this order and validate after capture:
  - ISO: `\b(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])\b`
  - Compact: `\b(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\b`
  - DMY (only if `--allow-dmy`): `\b(0[1-9]|[12]\d|3[01])[-_. ](0[1-9]|1[0-2])[-_. ](19|20)\d{2}\b`
  Verify: `test_date_from_name_*`.
- **R-0302 (STATE)** — WHILE no date is found in name, THE SYSTEM SHALL use `mtime` (default) or `ctime` if `--use-created`. Verify: `test_date_from_mtime`, `test_date_from_ctime`.
- **R-0303 (EVENT)** — WHEN `--fallback-today` is set and all else fails, THE SYSTEM SHALL use today’s date in local TZ or UTC if `--utc` is set. Verify: `test_date_fallback_today_*`.

## Collisions
- **R-0400 (EVENT)** — WHEN target exists, THE SYSTEM SHALL apply `--on-collision` policy:
  - `dedup`: append `-N` (`N≥1`) before the extension until unique.
  - `skip`: `action=skipped`, `reason=collision`.
  - `overwrite`: replace the existing file.
  Verify: `test_collision_*`.

## CLI & Discovery
- **R-0500 (UBIQUITOUS)** — THE SYSTEM SHALL accept paths to files/dirs; `--recursive` discovery with `--include-glob` / `--exclude-glob`. Verify: `test_discovery_recursive_filters`.
- **R-0501 (UBIQUITOUS)** — THE SYSTEM SHALL support: `--dry-run`, `--verbose`, `--quiet`, `--confirm`, `--stdout {plain|json}`, `--version`, `--infer-per-file`, `--multi-ext`, `--add-multi-ext EXT`, `--ext-case {lower|preserve}`, `--use-created`, `--allow-dmy`, `--utc`, `--on-collision {dedup|skip|overwrite}`, `--follow-symlinks`, `--force`. Verify: CLI matrix tests.

## Parsing & Validation
- **R-0600 (UBIQUITOUS)** — THE SYSTEM SHALL validate date components after regex capture and reject impossible dates (e.g., 2021-02-29). Verify: `test_date_validation_strict`.
- **R-0601 (UBIQUITOUS)** — THE SYSTEM SHALL ensure filename safety:
  - Remove/replace `<>:"/\\|?*` and control chars.
  - Forbid reserved Windows names (`CON, PRN, AUX, NUL, COM1..COM9, LPT1..LPT9`) ignoring extension.
  - Enforce path segment length ≤ `path_segment_max_bytes`.
  Verify: `test_cross_platform_safety`.

## Reporting
- **R-0700 (UBIQUITOUS)** — THE SYSTEM SHALL emit per-file reports with fields:
  `source_path:str`, `target_path:str|null`, `action:{renamed|skipped|error}`, `reason:str|null`, `date_source:{cli|name|ctime|mtime|today|null}`, `slug_source:{name|fallback|null}`, `collision_strategy:{dedup|skip|overwrite}`, `dry_run:bool`, `duration_ms:int`; modes `plain` and `json`. Verify: `test_reporting_*`.

## Safety
- **R-0800 (UBIQUITOUS)** — THE SYSTEM SHALL not follow symlinks unless `--follow-symlinks`. Verify: `test_symlink_policy`.
- **R-0801 (UNWANTED)** — IF atomic replace is unavailable THEN THE SYSTEM SHALL rename via a safe temp path and fsync directory. Verify: `test_atomic_or_fallback`.
- **R-0802 (UNWANTED)** — IF case-only rename on Windows THEN THE SYSTEM SHALL perform two-step rename. Verify: `test_windows_case_only_rename`.

## Code Quality & Tests
- **R-0900 (UBIQUITOUS)** — THE SYSTEM SHALL use small pure functions, explicit types, and docstrings; side effects isolated. Verify: lint/type checks.
- **R-0901 (UBIQUITOUS)** — THE SYSTEM SHALL provide `unittest` suites for slugify, date parsing, collisions, reporting, discovery, and executor; coverage ≥ `coverage_min_pct`. Verify: coverage report.
