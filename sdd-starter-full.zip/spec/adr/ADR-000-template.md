---
id: ADR-000
title: <decision>
status: Proposed
deciders: [<names>]
date: <YYYY-MM-DD>
---

## Context
<what led to this decision>

## Decision
<the choice made>

## Consequences
- <positive/negative consequences>

## Evidence
- <benchmarks, test runs, screenshots>
