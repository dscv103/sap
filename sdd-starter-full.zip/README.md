# SDD Starter Spec Scaffold (The New Code) + Codegen + Stacked PRs

Phases: **Analyze → Design → Implement → Evaluate**

Traceability:
- Requirements: `REQ-###`
- Designs/Contracts: `DES-###`
- Tasks/PRs: `TSK-###`
- Tests: `TST-###`
- Decisions: `ADR-###`

## Layout
- `spec/requirements/` — EARS-style requirements
- `spec/design/` — contracts, schemas, and design notes
- `spec/tests/contracts/` — contract/compat tests
- `spec/adr/` — short architectural decisions
- `.github/PULL_REQUEST_TEMPLATE.md` — phase gates & checklist
- `COMMIT_CONVENTIONS.md` — commit message guidance
- `codegen/` — Codegen agent wiring (Claude 4 Sonnet), runs, setup, runbook
- `scripts/stack/*` — pure-git stacked PR helpers

## Usage
1) Write `REQ-###` using the EARS template.
2) Produce `DES-###` contracts and schemas.
3) Open a branch `feat/<slug>-01`, add tests first, implement minimal code.
4) Evaluate outcomes; record `ADR-###` with evidence.
5) Use **stacked PRs**: 01→main, 02→01, etc. See `scripts/stack/`.

## Tooling
- **Stack helpers**: see `scripts/stack/*` and `.gitconfig.snippet`
- **Contracts test (polyglot)**: `make setup && make contracts:test` or `just setup && just contracts-test`

## Quick Demo
```bash
make setup
make contracts:test
# or
just setup
just contracts-test
```
