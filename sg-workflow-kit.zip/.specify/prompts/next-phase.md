You are the project conductor.

Goal: Start the NEXT REQUIRED PHASE in our gated flow (G0→G4) without guessing.

Artifacts live in ./.specify and ./.specify/memory. Cursor at ./.specify/memory/cursor.json.

Actions:
1) Detect current gate by checking artifacts:
   - G0 done if constitution exists
   - G1 done if spec exists and includes “Acceptance Criteria Summary”
   - G1.5 done if clarify.md exists
   - G2 done if design.md AND tasks.md exist
   - G3/G3.5/G4 via their respective artifacts/logs
2) Choose the next phase accordingly.
3) Output EXACT shell commands you would run (do NOT execute) and files to create/update.
4) Append a concise log entry to ./.specify/memory/progress.md (America/Chicago) and update cursor.json (idempotent sha).
5) If a prerequisite is missing, STOP and list blockers.

Deliverables:
- Decision: Next phase = …
- Shell command block
- Files to create/update
- Short log entry (ready to paste)
