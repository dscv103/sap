#!/usr/bin/env bash
set -euo pipefail
# stack-clean <slug> [from=01] [to=20]
slug=${1:?usage: stack-clean <slug> [from] [to]}
from=${2:-01}; to=${3:-20}
for i in $(seq -w ${from} ${to}); do
  b="feat/${slug}-${i}"
  if git show-ref --verify --quiet "refs/heads/${b}"; then
    git branch -D "${b}"
    echo "Deleted local ${b}"
  fi
done
