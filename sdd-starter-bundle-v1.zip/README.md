# SDD Starter (Spec‑Driven Design)

A batteries-included starter for **Spec‑Driven Design (SDD)** with:
- Requirements & Design specs (REQ/DES) + ADRs
- Thin vertical slices (`/backlog/TSK-*`) with JSON handoff cards
- Traceability (REQ → DES → TSK → PR → Code → Tests)
- Spec linter + CI workflow
- Minimal TypeScript code + Jest tests implementing the example feature
- Learning Records (LRN)

> Philosophy: **specs are the source of truth**; code + tests trace back to acceptance criteria.

---

## Quickstart

```bash
# 1) Install toolchain
corepack enable || true
npm i

# 2) Run checks & tests
npm test
npm run lint:spec

# 3) Generate/refresh trace matrix
npm run trace

# 4) Try the first slice locally (already implemented)
npm run test -t AC-1
```

### What you get
- `specs/REQ/REQ-101-reservations.md` – example feature spec with two acceptance criteria
- `specs/DES/DES-101-reservations.md` – API/data contract
- `backlog/TSK-101-01.md` – first slice (happy path) with JSON handoff
- `src/api/reserve.ts` + `tests/api/reserve.spec.ts` – code + tests with REQ/AC trace tags
- `scripts/spec-lint.sh` – tiny linter that enforces acceptance + mapping
- `scripts/trace-matrix.py` – builds `docs/TRACEABILITY.md`
- GitHub Actions workflow to run all of the above on PRs

### Requirements
- Node.js 20+
- `yq` for `spec-lint.sh` (CI installs it automatically). On Fedora: `sudo dnf install yq`.

---

## Conventions

- Tag code with `// REQ:<id> AC:<n>`
- Name tests with `AC-<n>_*`
- Map all acceptance bullets to tests in `tests/specmap/REQ-*.yml`
- Each PR references one `TSK-*` and the associated `REQ-*`/`DES-*`
- Create an `LRN-*` record per merged slice

---

## Next steps

- Duplicate the REQ/DES/TSK pattern for your next feature.
- Keep slices 30–120 LOC changes to maintain speed & reviewability.
- Evolve the templates; they are yours.
