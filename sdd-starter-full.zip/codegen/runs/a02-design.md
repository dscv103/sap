Task: Produce DES-### contract and JSON Schema draft
Phase: Design
Context: REQ-###, spec/design/schemas
Constraints: Prefer additive compatibility; version schema as *.v1.json
Deliverables: diffs, tests, docs, ADR (if needed)
Checks: make contracts:test
Trace: REQ-###, DES-###, TST-###

- Add error taxonomy and invariants.
- Outline contract tests.
