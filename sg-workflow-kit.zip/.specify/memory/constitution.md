# Project Constitution — NixOS Workstation (flake‑parts)

**Owner:** Derek (R) • **Approver(s):** Reviewer (A), Ops (A at release) • **Informed:** Stakeholders  
**Document ID:** constitution.md • **Location:** `./.specify/memory/constitution.md`  
**Governs:** Spec, Design, Tasks, Tests, CI, Releases

---

## 1) Principles (non‑negotiable)
1. **Executable Spec.** Spec drives acceptance; ACs must be machine‑verifiable.  
2. **Reproducibility.** Flakes + flake‑parts only; nixpkgs **unstable** is pinned.  
3. **Latest kernel.** Use latest stable at pin; exceptions require ADR + rollback.  
4. **Binary‑cache first.** Substitution enabled; official cache + key configured; extra caches via ADR.  
5. **Security.** No plaintext secrets; if needed, sops‑nix. Least‑privilege.  
6. **Networking policy.** Wired‑only; Wi‑Fi/Bluetooth disabled unless ADR.  
7. **UX boundaries.** VS Code `settings.json` remains **user‑mutable**. GNOME on Wayland; Ghostty terminal.  
8. **Approvals & Gates.** G0..G4 must pass with required sign‑offs.  
9. **Traceability.** Every REQ links to design/tasks/tests; changes require ADR.  
10. **Rollback.** Releases include one‑command rollback; provenance captured.

## 2) Gated Workflow
- **G0**: Constitution present + report.  
- **G1**: Spec Freeze; SLOs defined.  
- **G1.5**: Clarify open issues; ADRs for trade‑offs.  
- **G2**: Design + Tasks freeze.  
- **G3**: Coverage + checklist + CI green.  
- **G3.5**: Implement hand‑off & run log.  
- **G4**: Release bundle + rollback.

## 3) CI Enforcement
- Spec lint (IDs/sections).  
- Policy tests: user‑mutable VS Code settings; radios off; binary cache enabled.  
- Substitution SLO ≥ 0.80 on clean CI.  
- Approvals per gate present; failing checks block merge.

## 4) Exceptions
- Must be recorded as ADR (motivation, scope, rollback, sunset).  
- Same approvers as affected gate.

## 5) RACI
| Artifact/Action | R | A | C | I |
|---|---|---|---|---|
| Constitution | Owner | Reviewer | Ops | Stakeholders |
| Spec/Design/Tasks | Owner | Reviewer | Ops | Stakeholders |
| CI/Tests | Owner | Reviewer | Ops | Stakeholders |
| Releases | Owner | Reviewer + Ops | — | Stakeholders |

## 6) Change History
- v1.0 — Initial constitution aligned to Spec v1.5.
