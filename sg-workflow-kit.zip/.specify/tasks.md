# NixOS Configuration — Tasks (docs‑only, actionable plan)

> This file enumerates **atomic, verifiable tasks** aligned to the Spec. Use it to drive PRs. IDs: `T‑<AREA>‑NNN`.

---

## Gate Tasks

- **T‑G0‑001** — Commit `./.specify/memory/constitution.md`. Create `progress.md` and `cursor.json`.  
- **T‑G1‑001** — Finalize `spec.md`; add Acceptance Criteria Summary; tag `spec/v1.0`.  
- **T‑G1.5‑001** — Run clarify; commit `clarify.md`; open ADRs for open issues.  
- **T‑G2‑001** — Finalize `design.md` (contracts) and this `tasks.md`.  
- **T‑G3‑001** — Prepare CI checks and test scaffolds (to be implemented alongside code).  
- **T‑G3.5‑001** — Capture `/speckit.implement` run log.  
- **T‑G4‑001** — Prepare release bundle + rollback instructions.

---

## Feature Tasks (for implementation phase)

### Kernel (REQ‑KERNEL‑001..003)
- **T‑KERNEL‑001** — Set kernel to **latest stable** at pin; expose `boot.kernelPackages`.  
- **T‑KERNEL‑002** — Add probe to verify `uname -r` and module load.

### Filesystem/Boot (REQ‑FS‑001..004)
- **T‑FS‑001** — Configure LUKS root + bcachefs + systemd‑boot (EFI).  
- **T‑FS‑002** — Probe: `lsblk`, `mount`, `bootctl status` checks.

### Desktop (REQ‑DESK‑001..002)
- **T‑DESK‑001** — Enable GNOME on Wayland; XWayland present; forbid default Xorg.  
- **T‑DESK‑002** — Probe: `$XDG_SESSION_TYPE=wayland` + legacy app run test.

### GPU (REQ‑GPU‑001..003)
- **T‑GPU‑001** — Enable NVIDIA proprietary driver; ensure Vulkan.  
- **T‑GPU‑002** — Probe: `nvidia-smi`, `vulkaninfo` outputs collected.

### Network (REQ‑NET‑001..003)
- **T‑NET‑001** — Configure Ethernet‑only backend; default‑deny firewall.  
- **T‑NET‑002** — Disable Wi‑Fi + Bluetooth; rfkill.  
- **T‑NET‑003** — Probe: `nmcli radio`, `systemctl status bluetooth`, firewall dump.

### Audio (REQ‑AUDIO‑001)
- **T‑AUDIO‑001** — Enable PipeWire + WirePlumber; disable PulseAudio.  
- **T‑AUDIO‑002** — Probe: user units and device presence.

### Locale/Time (REQ‑LOCALE‑001..002)
- **T‑LOC‑001** — Set locale/timezone.  
- **T‑LOC‑002** — Probe: `locale`, `timedatectl` verification.

### Dev UX (REQ‑DEV‑001..003)
- **T‑DEV‑001** — Install VS Code/VSCodium; **do not manage** `settings.json`.  
- **T‑DEV‑002** — Provide dev shells + direnv.  
- **T‑DEV‑003** — Probe: user’s `settings.json` writable; `nix develop` + `direnv` work (when code exists).

### Shell/Terminal (REQ‑SHELL‑001, REQ‑TERM‑001)
- **T‑SHELL‑001** — Set Zsh default; Starship enabled.  
- **T‑TERM‑001** — Make Ghostty the default terminal; bind GNOME launcher.  
- **T‑SHELL‑002** — Probes: `$SHELL`, `starship --version`, Ghostty present.

### Binary‑Cache (REQ‑BINCACHE‑001..004)
- **T‑CACHE‑001** — Turn on substitution; add official cache + keys; optional ADR caches.  
- **T‑CACHE‑002** — Probe: `nix show-config` + compute **substitution_rate** ≥ 0.80 on clean CI.

### Security/Observability/Backup
- **T‑SEC‑001** — Enforce “no plaintext secrets”; wire sops only if needed (ADR).  
- **T‑OBS‑001** — journald rotation; optional persistence.  
- **T‑BKP‑001** — Document snapshot/backup approach.

---

## Verification Tasks

- **T‑EVAL‑001** — Build a probe script that emits `report.json` with AC statuses and `substitution_rate`.  
- **T‑EVAL‑002** — Add “spec‑lint” to verify REQ ID patterns and section presence.  
- **T‑EVAL‑003** — CI job to fail on red ACs/SLOs.

---

## Traceability Tasks

- **T‑TRACE‑001** — Create a matrix mapping REQs → Modules → Probes.  
- **T‑TRACE‑002** — Enforce updates across Spec/Design/Tasks when a REQ changes.

