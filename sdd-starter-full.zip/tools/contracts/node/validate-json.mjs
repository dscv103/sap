#!/usr/bin/env node
import fs from 'fs';
import path from 'path';
import process from 'process';
import Ajv from 'ajv';

const [, , schemaPath, ...dataGlobs] = process.argv;
if (!schemaPath || dataGlobs.length === 0) {
  console.error('usage: node validate-json.mjs <schema.json> <data.json...>');
  process.exit(2);
}

function expand(glob) {
  if (!glob.includes('*')) return [glob];
  const dir = path.dirname(glob);
  const pattern = path.basename(glob)
    .replace(/[.+^${}()|[\]\\]/g, '\\$&')
    .replace(/\*/g, '.*');
  const rx = new RegExp('^' + pattern + '$');
  return fs.readdirSync(dir).filter(f => rx.test(f)).map(f => path.join(dir, f));
}

const ajv = new Ajv({ allErrors: true, strict: false });
const schema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
const validate = ajv.compile(schema);

let failures = 0;
for (const g of dataGlobs) {
  for (const fp of expand(g)) {
    const data = JSON.parse(fs.readFileSync(fp, 'utf8'));
    const ok = validate(data);
    if (!ok) {
      failures++;
      console.log(`❌ ${fp}`);
      for (const e of (validate.errors || []).slice(0, 5)) {
        const loc = e.instancePath || '<root>';
        console.log(`  - ${loc}: ${e.message}`);
      }
    } else {
      console.log(`✅ ${fp}`);
    }
  }
}

process.exit(failures ? 1 : 0);
