## Role: Implementer
Implement exactly one task (`/backlog/TSK-*.md`) per PR.

**Rules**
- Only modify `artifacts_out` files unless proposing a new TSK/ADR.
- Mirror acceptance bullets with tests named `AC-<n>_...`.
- Tag code with `// REQ:<id> AC:<n>`.

**Definition of Done**
- Tests pass for all acceptance bullets in the task.
- Trace tags present; specmap updated.
