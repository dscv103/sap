# RUNBOOK — SDD + Codegen + Stacked PRs (Polyglot)

This runbook gives you a single-page flow to execute **The New Code** (Analyze → Design → Implement → Evaluate) using
the Codegen agent (Claude 4 Sonnet), repository rules, stacked PRs, and the polyglot contract-test harness.

---

## 0) Prep
- Ensure repo contains: `AGENTS.md`, `.cursor/rules/core.mdc`, `codegen/*`, `spec/*`, `scripts/stack/*`, `Makefile`, `justfile`.
- In **Codegen → Repo Settings**:
  - Paste **Setup Commands** from `codegen/SETUP.md`, run, then **Snapshot**.
  - Set **Model** to **Claude 4 Sonnet** (or matching workspace identifier).
  - Enable **PR creation** and **Repository Rule detection**.
- In GitHub:
  - Ensure `.github/workflows/contracts-test.yml` exists (runs contract tests on PR).

---

## 1) Analyze (problem framing)
**Goal**: Author an EARS requirement (`REQ-###`) with examples, non-goals, and success criteria.

**Codegen run**: open `codegen/runs/a01-analyze.md` and fill placeholders.  
**Human actions**:
1. Save as `spec/requirements/REQ-xyz.md`.
2. Commit with trace:
   ```bash
   git checkout -B feat/<slug>-01 origin/main
   git add spec/requirements/REQ-xyz.md
   git commit -m "docs(REQ-xyz): EARS requirement with examples"
   git push -u origin HEAD
   ```
3. Open PR: base = `main`. (Small edits only.)

**Exit criteria**: REQ reviewed/approved; examples are testable.

---

## 2) Design (contracts first)
**Goal**: Produce `DES-###` and initial contract (e.g., JSON Schema) + test plan.

**Codegen run**: `codegen/runs/a02-design.md` (input the new `REQ-xyz`).  
**Artifacts**: `spec/design/DES-abc.md`, `spec/design/schemas/<name>.v1.json`, test plan notes.

**Commands**:
```bash
make setup
make contracts:test
```

**Commit/stack**:
```bash
git checkout -B feat/<slug>-02 feat/<slug>-01
git add spec/design/DES-abc.md spec/design/schemas/*.json
git commit -m "docs(DES-abc): contract + schema v1 for REQ-xyz"
git push -u origin HEAD
```
Open PR: base = `feat/<slug>-01`.

**Exit criteria**: DES approved; schema exists; test plan clear.

---

## 3) Implement (tests first, minimal diffs)
**Goal**: Add failing tests, implement minimal code to green, keep files ≈250 LOC, split by responsibility.

**Codegen run**: `codegen/runs/a03-implement.md` (provide DES + target paths).  
**Local verify**:
```bash
make contracts:test
# add app/unit/integration tests per language as needed
```

**Commit/stack**:
```bash
git checkout -B feat/<slug>-03 feat/<slug>-02
# add code + tests
git commit -m "feat: minimal slice for REQ-xyz (TST-123)"
git push -u origin HEAD
```
Open PR: base = `feat/<slug>-02`.

**Exit criteria**: tests green locally and in CI; PR minimal and reviewable.

---

## 4) Iterate (flagged expansion)
**Goal**: Extend behind a feature flag; add integration/contract tests if contract evolves additively.

**Codegen run**: `codegen/runs/a04-iterate.md`.  
**Commit/stack**:
```bash
git checkout -B feat/<slug>-04 feat/<slug>-03
git commit -m "feat(flag): extend behavior behind <flag> (contract additive)"
git push -u origin HEAD
```

**Exit criteria**: CI still green; no breaking changes; flag default off.

---

## 5) Evaluate (evidence & ADR)
**Goal**: Compare outcome against REQ success criteria; record decision in ADR.

**Codegen run**: `codegen/runs/a05-evaluate.md`.  
**Artifacts**: `spec/adr/ADR-###.md` with decision, evidence, follow-ups.

**Commit**:
```bash
git checkout feat/<slug>-04
git add spec/adr/ADR-###.md
git commit -m "docs(ADR-###): evaluation for REQ-xyz"
git push
```

**Exit criteria**: ADR merged; follow-ups queued.

---

## Rebase the stack when main moves
```bash
scripts/stack/stack-rebase.sh <slug> origin/main
git push --force-with-lease origin feat/<slug>-01 feat/<slug>-02 feat/<slug>-03 feat/<slug>-04
```

---

## PR Checklist (DoD summary)
- [ ] Tests added/updated and **failing-first → green**.
- [ ] Contracts unchanged or versioned; compatibility and migration/rollback noted.
- [ ] Scope small (≈200–400 LOC changed), isolated.
- [ ] Docs/README/CHANGELOG updated when user-visible.
- [ ] No secrets or placeholders introduced.
- [ ] CI `contracts-test` job green.

---

## Quick Commands
```bash
# Start stack
scripts/stack/stack-new.sh <slug> 01 origin/main
scripts/stack/stack-next.sh <slug> 01

# Contracts test harness
make setup && make contracts:test
# or
just setup && just contracts-test

# Push + PRs (then chain bases in UI)
scripts/stack/stack-submit.sh <slug>
```
