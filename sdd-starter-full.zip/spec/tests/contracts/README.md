# Contract Tests

Add tests that validate runtime payloads against schemas (JSON Schema, Protobuf, OpenAPI, etc.).

Suggested cases:
- Happy-path payload validates
- Missing required field fails with clear error
- Additional/unknown field policy enforced
- Back/forward compatibility fixtures
