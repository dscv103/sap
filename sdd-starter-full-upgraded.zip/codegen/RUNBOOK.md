# RUNBOOK

---

## Self-Learning / Self-Healing Loop
After **Evaluate**, run Detect→Diagnose→Decide→Deliver→Document.

- **Detect:** spec-lint, contract-drift, flake-watch (CI)
- **Diagnose:** open LRN-### (use `learn/templates/LRN-000-template.md`)
- **Decide:** hotfix vs next-iteration vs policy update
- **Deliver:** tests-first fix or schedule into next Analyze
- **Document:** append to `learn/records.jsonl`, update ADR/AGENTS/RUNBOOK if policy/arch changed
