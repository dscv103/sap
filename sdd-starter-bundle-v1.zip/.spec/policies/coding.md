# Coding Policy
- Keep slices small; prefer clarity over cleverness.
- Public interfaces documented in DES; do not diverge.
- Add `// REQ:<id> AC:<n>` near each line implementing an acceptance bullet.
