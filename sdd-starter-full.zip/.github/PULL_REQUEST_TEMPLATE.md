## Summary
Link: TSK-### (Relates: REQ-###, DES-###)

## What changed
- <short bullets>

## Phase & Gates
- Phase: Analyze / Design / Implement / Evaluate (choose one)

### Checks
- [ ] Tests added/updated and **fail first**, then pass
- [ ] Contracts unchanged or versioned (schemas updated if needed)
- [ ] Back/forward compatibility respected or migration noted
- [ ] Docs/README/CHANGELOG updated when user-visible
- [ ] No secrets or placeholders introduced

## Run Book
```sh
<commands to lint/test/build/e2e>
```

## Risk & Rollback
- Risk Level: Low | Medium | High
- Rollback Plan: <steps>

## Stack Info (if part of a stack)
- Branch base: `main` | `feat/<slug>-NN` (choose one)
- Next branch (if any): `feat/<slug>-NN+1`
- Rebase guidance: `scripts/stack/stack-rebase.sh <slug> origin/main`
