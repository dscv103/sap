---
id: LRN-000
date: <YYYY-MM-DD>
signal: [spec_drift|contract_drift|test_flake|slo_breach|alignment_gap]
component: <module/service>
trace: [REQ-###, DES-###, TST-###, ADR-###]
---

## Symptom
Short description of the issue detected.

## Evidence
- Logs, failing fixtures, screenshots, metrics

## Diagnosis
- Root cause hypothesis and scope

## Decision
- hotfix|next-iteration|policy-update
- If hotfix: PR link
- If policy: AGENTS.md/.cursor/core changes

## Remediation
- Tasks created (TSK-###), owners, due dates

## Diffusion
- RUNBOOK/SETUP updates, ADR if architecture/policy changed
